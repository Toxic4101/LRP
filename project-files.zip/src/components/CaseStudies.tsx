import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { PROJECTS, Project } from '../data/projects';

interface CaseStudiesProps {
  onSelectProject: (project: Project) => void;
}

export function CaseStudies({ onSelectProject }: CaseStudiesProps) {
  return (
    <section id="works" className="py-24 px-6 md:px-12 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-400 mb-2 font-mono-tabular">
            <span>Selected Projects</span>
            <span aria-hidden="true">·</span>
            <span>2025–2026</span>
            <span aria-hidden="true">·</span>
            <span>Commercial & Flagship</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
            Flagship Websites & Case Studies
          </h2>
        </div>
        <p className="text-stone-400 text-sm max-w-md font-body">
          Explore recent client commissions engineered for conversion, brand prestige, and technical longevity.
        </p>
      </div>

      {/* Project Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {PROJECTS.map((project) => (
          <article 
            key={project.id}
            onClick={() => onSelectProject(project)}
            className="group cursor-pointer bg-stone-900/60 border border-stone-800 hover:border-stone-700 rounded-xl overflow-hidden transition-all duration-200 flex flex-col justify-between"
          >
            <div>
              {/* Media Slot 4:3 with zero-broken image policy */}
              <div className="relative aspect-4/3 bg-stone-950 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-stone-950/20 group-hover:bg-transparent transition-colors" />
                
                {/* Subtle Hover Affordance */}
                <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-stone-950/80 border border-stone-700 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="w-4 h-4 text-stone-200" />
                </div>
              </div>

              {/* Content Block */}
              <div className="p-6">
                {/* Zero-Pill Unboxed Metadata */}
                <div className="flex items-center gap-2 text-xs text-stone-400 mb-2">
                  <span>{project.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">{project.year}</span>
                </div>

                <h3 className="text-xl font-display font-semibold text-stone-100 group-hover:text-amber-400 transition-colors">
                  {project.title}
                </h3>

                <p className="mt-3 text-xs sm:text-sm text-stone-400 line-clamp-3 font-body leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>

            {/* Adjacent Proof Metric */}
            <div className="p-6 pt-0 mt-2 border-t border-stone-800/60">
              <div className="pt-4 flex items-center justify-between text-xs">
                <div>
                  <div className="font-mono-tabular text-base font-bold text-stone-100">
                    {project.metrics[0].primary}
                  </div>
                  <div className="text-[11px] text-stone-500">
                    {project.metrics[0].label}
                  </div>
                </div>
                <span className="text-xs text-amber-400 group-hover:translate-x-1 transition-transform inline-flex items-center gap-1 font-medium">
                  View Case Study
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
