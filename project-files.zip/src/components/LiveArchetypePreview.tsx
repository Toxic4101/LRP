import React, { useState } from 'react';
import { ShoppingBag, Building, LayoutDashboard, Utensils, Check, ArrowRight, Laptop, Tablet, Smartphone, Calendar, User, Star } from 'lucide-react';

export type ArchetypeId = 'ecommerce' | 'architecture' | 'saas' | 'hospitality';

export function LiveArchetypePreview() {
  const [activeArchetype, setActiveArchetype] = useState<ArchetypeId>('ecommerce');
  const [viewportMode, setViewportMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  
  // Interactive states for e-commerce demo
  const [selectedFinish, setSelectedFinish] = useState<'obsidian' | 'titanium' | 'brass'>('obsidian');
  const [cartCount, setCartCount] = useState<number>(0);
  const [cartFeedback, setCartFeedback] = useState<string | null>(null);

  // Interactive states for architecture demo
  const [viewAngle, setViewAngle] = useState<'elevation' | 'materials' | 'site'>('elevation');

  // Interactive states for SaaS demo
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('annual');
  const [seats, setSeats] = useState<number>(12);

  // Interactive states for hospitality demo
  const [guests, setGuests] = useState<number>(2);
  const [bookingConfirmed, setBookingConfirmed] = useState<boolean>(false);

  const handleAddToCart = () => {
    setCartCount(prev => prev + 1);
    setCartFeedback('Added to bag');
    setTimeout(() => setCartFeedback(null), 2000);
  };

  const getViewportMaxWidth = () => {
    switch (viewportMode) {
      case 'mobile': return 'max-w-[390px]';
      case 'tablet': return 'max-w-[720px]';
      default: return 'w-full';
    }
  };

  return (
    <section id="prototypes" className="py-24 px-6 md:px-12 max-w-7xl mx-auto border-t border-stone-800">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-400 mb-2">
            <span>Live Interactive Demos</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Latency Prototypes</span>
            <span aria-hidden="true">·</span>
            <span>Fully Responsive</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
            Interactive Archetypes You Can Build
          </h2>
          <p className="mt-3 text-stone-400 text-sm md:text-base max-w-2xl font-body">
            Every website we engineer is custom-architected for its industry. Test the live interactive widgets below to experience tactile responsiveness, layout math, and state management.
          </p>
        </div>

        {/* Viewport Simulation Controls */}
        <div className="flex items-center gap-2 bg-stone-900 border border-stone-800 p-1.5 rounded-lg shrink-0">
          <span className="text-xs text-stone-400 px-2 font-mono-tabular">Viewport:</span>
          <button
            onClick={() => setViewportMode('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              viewportMode === 'desktop' ? 'bg-stone-800 text-stone-100 shadow-sm' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Desktop 1440px"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Desktop</span>
          </button>
          <button
            onClick={() => setViewportMode('tablet')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              viewportMode === 'tablet' ? 'bg-stone-800 text-stone-100 shadow-sm' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Tablet 768px"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Tablet</span>
          </button>
          <button
            onClick={() => setViewportMode('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              viewportMode === 'mobile' ? 'bg-stone-800 text-stone-100 shadow-sm' : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Mobile 390px"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mobile</span>
          </button>
        </div>
      </div>

      {/* Archetype Selector Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <button
          onClick={() => setActiveArchetype('ecommerce')}
          className={`flex items-center gap-3 p-4 text-left border rounded-lg transition-all ${
            activeArchetype === 'ecommerce'
              ? 'bg-stone-900 border-amber-500/50 shadow-sm ring-1 ring-amber-500/30'
              : 'bg-stone-950/60 border-stone-800 hover:border-stone-700 text-stone-400 hover:text-stone-200'
          }`}
        >
          <ShoppingBag className={`w-5 h-5 shrink-0 ${activeArchetype === 'ecommerce' ? 'text-amber-400' : 'text-stone-500'}`} />
          <div className="truncate">
            <div className="text-sm font-semibold text-stone-100 truncate">Luxury E-Commerce</div>
            <div className="text-xs text-stone-400 truncate">Retail & Merchant Flagship</div>
          </div>
        </button>

        <button
          onClick={() => setActiveArchetype('architecture')}
          className={`flex items-center gap-3 p-4 text-left border rounded-lg transition-all ${
            activeArchetype === 'architecture'
              ? 'bg-stone-900 border-amber-500/50 shadow-sm ring-1 ring-amber-500/30'
              : 'bg-stone-950/60 border-stone-800 hover:border-stone-700 text-stone-400 hover:text-stone-200'
          }`}
        >
          <Building className={`w-5 h-5 shrink-0 ${activeArchetype === 'architecture' ? 'text-amber-400' : 'text-stone-500'}`} />
          <div className="truncate">
            <div className="text-sm font-semibold text-stone-100 truncate">Studio Architecture</div>
            <div className="text-xs text-stone-400 truncate">Editorial & Portfolio Archive</div>
          </div>
        </button>

        <button
          onClick={() => setActiveArchetype('saas')}
          className={`flex items-center gap-3 p-4 text-left border rounded-lg transition-all ${
            activeArchetype === 'saas'
              ? 'bg-stone-900 border-amber-500/50 shadow-sm ring-1 ring-amber-500/30'
              : 'bg-stone-950/60 border-stone-800 hover:border-stone-700 text-stone-400 hover:text-stone-200'
          }`}
        >
          <LayoutDashboard className={`w-5 h-5 shrink-0 ${activeArchetype === 'saas' ? 'text-amber-400' : 'text-stone-500'}`} />
          <div className="truncate">
            <div className="text-sm font-semibold text-stone-100 truncate">SaaS Platform</div>
            <div className="text-xs text-stone-400 truncate">Web Application & Portal</div>
          </div>
        </button>

        <button
          onClick={() => setActiveArchetype('hospitality')}
          className={`flex items-center gap-3 p-4 text-left border rounded-lg transition-all ${
            activeArchetype === 'hospitality'
              ? 'bg-stone-900 border-amber-500/50 shadow-sm ring-1 ring-amber-500/30'
              : 'bg-stone-950/60 border-stone-800 hover:border-stone-700 text-stone-400 hover:text-stone-200'
          }`}
        >
          <Utensils className={`w-5 h-5 shrink-0 ${activeArchetype === 'hospitality' ? 'text-amber-400' : 'text-stone-500'}`} />
          <div className="truncate">
            <div className="text-sm font-semibold text-stone-100 truncate">Artisanal Dining</div>
            <div className="text-xs text-stone-400 truncate">Culinary Booking & Experience</div>
          </div>
        </button>
      </div>

      {/* Frame Container */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 md:p-8 flex justify-center transition-all">
        <div className={`transition-all duration-300 w-full ${getViewportMaxWidth()} bg-stone-950 border border-stone-800 rounded-lg overflow-hidden shadow-2xl`}>
          
          {/* Simulated Browser Bar */}
          <div className="bg-stone-900 border-b border-stone-800 px-4 py-2.5 flex items-center justify-between text-xs text-stone-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-stone-700 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-stone-700 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-stone-700 inline-block"></span>
            </div>
            <div className="font-mono-tabular text-stone-400 text-[11px] truncate px-3 py-0.5 bg-stone-950 rounded border border-stone-800 max-w-[280px]">
              https://preview.{activeArchetype}.vanguard-studio.co
            </div>
            <div className="font-mono-tabular text-[11px] text-amber-400">
              {viewportMode === 'desktop' ? '1440 × 900' : viewportMode === 'tablet' ? '768 × 1024' : '390 × 844'}
            </div>
          </div>

          {/* Interactive Screen Body */}
          <div className="p-6 md:p-8 min-h-[460px] flex flex-col justify-between">
            {activeArchetype === 'ecommerce' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                  <div className="font-display font-semibold text-lg text-stone-100">KRONOS ATELIER</div>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-stone-400 hidden sm:inline">Timepieces · Accessories</span>
                    <button className="flex items-center gap-1.5 px-3 py-1 bg-stone-900 border border-stone-700 rounded text-stone-200">
                      <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                      <span className="font-mono-tabular">Bag ({cartCount})</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  <div className="bg-stone-900/80 border border-stone-800 rounded-lg p-6 flex flex-col items-center justify-center relative min-h-[220px]">
                    <div className="w-28 h-28 rounded-full border-4 border-stone-700 flex items-center justify-center shadow-inner relative"
                      style={{
                        backgroundColor: selectedFinish === 'obsidian' ? '#1c1917' : selectedFinish === 'titanium' ? '#292524' : '#451a03',
                        borderColor: selectedFinish === 'obsidian' ? '#44403c' : selectedFinish === 'titanium' ? '#78716c' : '#b45309'
                      }}
                    >
                      <div className="w-1.5 h-12 bg-amber-400 rounded-full origin-bottom rotate-45 transform"></div>
                      <div className="w-2 h-2 rounded-full bg-amber-400 absolute"></div>
                    </div>
                    <div className="mt-4 text-center">
                      <div className="text-xs text-stone-400">Model 01 · Automatic Tourbillon</div>
                      <div className="font-mono-tabular text-sm text-stone-200 font-semibold mt-0.5">$4,250 USD</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="text-xs text-stone-400 mb-1">Edition Case Material</div>
                      <div className="flex items-center gap-2">
                        {(['obsidian', 'titanium', 'brass'] as const).map(finish => (
                          <button
                            key={finish}
                            onClick={() => setSelectedFinish(finish)}
                            className={`px-3 py-1.5 text-xs font-medium rounded border transition-colors capitalize ${
                              selectedFinish === finish
                                ? 'bg-amber-400 text-stone-950 border-amber-400 font-semibold'
                                : 'bg-stone-900 border-stone-800 text-stone-300 hover:border-stone-700'
                            }`}
                          >
                            {finish}
                          </button>
                        ))}
                      </div>
                    </div>

                    <p className="text-xs text-stone-400 leading-relaxed font-body">
                      Machined from solid grade-5 block with 72-hour power reserve and scratch-resistant sapphire crystal front and exhibition caseback.
                    </p>

                    <div className="pt-2 flex items-center gap-3">
                      <button
                        onClick={handleAddToCart}
                        className="px-5 py-2.5 bg-stone-100 hover:bg-white text-stone-950 text-xs font-semibold rounded transition-colors flex items-center gap-2"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Add to Order</span>
                      </button>
                      {cartFeedback && (
                        <span className="text-xs text-emerald-400 flex items-center gap-1 font-medium">
                          <Check className="w-3.5 h-3.5" />
                          <span>{cartFeedback}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeArchetype === 'architecture' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                  <div className="font-display font-semibold text-lg text-stone-100">STUDIO NORDIC / ARCHITECTURE</div>
                  <div className="text-xs text-stone-400 font-mono-tabular">Helsinki · Project Archive</div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    {(['elevation', 'materials', 'site'] as const).map(angle => (
                      <button
                        key={angle}
                        onClick={() => setViewAngle(angle)}
                        className={`px-3 py-1.5 text-xs font-medium rounded border transition-colors capitalize ${
                          viewAngle === angle
                            ? 'bg-stone-100 text-stone-950 border-stone-100 font-semibold'
                            : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        {angle === 'elevation' ? 'Blueprint Elevation' : angle === 'materials' ? 'Material Palette' : 'Topography Context'}
                      </button>
                    ))}
                  </div>

                  <div className="p-6 bg-stone-900 border border-stone-800 rounded-lg min-h-[190px] flex flex-col justify-center">
                    {viewAngle === 'elevation' && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-xs text-stone-400 font-mono-tabular">
                          <span>Cross Section 04 — North Elevation</span>
                          <span>Scale 1:50</span>
                        </div>
                        <div className="h-20 border-b-2 border-dashed border-stone-600 flex items-end justify-around px-8">
                          <div className="w-16 h-14 bg-stone-800 border border-stone-600"></div>
                          <div className="w-24 h-18 bg-stone-800 border border-stone-600"></div>
                          <div className="w-12 h-10 bg-stone-800 border border-stone-600"></div>
                        </div>
                        <div className="text-xs text-stone-400 font-mono-tabular text-right">Cantilever Offset: +2.40m</div>
                      </div>
                    )}

                    {viewAngle === 'materials' && (
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="p-3 bg-stone-950 border border-stone-800 rounded">
                          <div className="h-8 bg-amber-950/40 border border-amber-900/30 rounded mb-2"></div>
                          <div className="text-xs font-semibold text-stone-200">Charred Larch</div>
                          <div className="text-[11px] text-stone-400">Exterior Cladding</div>
                        </div>
                        <div className="p-3 bg-stone-950 border border-stone-800 rounded">
                          <div className="h-8 bg-stone-800 rounded mb-2"></div>
                          <div className="text-xs font-semibold text-stone-200">Basalt Stone</div>
                          <div className="text-[11px] text-stone-400">Foundation Plinth</div>
                        </div>
                        <div className="p-3 bg-stone-950 border border-stone-800 rounded">
                          <div className="h-8 bg-zinc-700/60 rounded mb-2"></div>
                          <div className="text-xs font-semibold text-stone-200">Low-Iron Glass</div>
                          <div className="text-[11px] text-stone-400">Thermally Broken</div>
                        </div>
                      </div>
                    )}

                    {viewAngle === 'site' && (
                      <div className="text-xs text-stone-300 space-y-2">
                        <div className="font-semibold text-stone-100">Porvoo Archipelago Pavilion</div>
                        <p className="text-stone-400 text-xs leading-relaxed">
                          Oriented strictly toward south-southwest exposure to capture low winter solar gain while preserving centuries-old coastal pine canopies.
                        </p>
                        <div className="font-mono-tabular text-[11px] text-stone-500 pt-1">
                          Latitude 60°23′N · Longitude 25°39′E
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeArchetype === 'saas' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                  <div className="font-display font-semibold text-lg text-stone-100">NEXUS METRICS</div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setBillingPeriod(billingPeriod === 'monthly' ? 'annual' : 'monthly')}
                      className="px-2.5 py-1 text-xs font-mono-tabular bg-stone-900 border border-stone-700 rounded text-stone-300 hover:text-stone-100"
                    >
                      {billingPeriod === 'annual' ? 'Annual (20% off)' : 'Monthly'}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                  <div className="bg-stone-900 border border-stone-800 rounded-lg p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-stone-400">Active Workspace Seats</span>
                      <span className="font-mono-tabular font-bold text-amber-400 text-sm">{seats} members</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="100"
                      value={seats}
                      onChange={e => setSeats(Number(e.target.value))}
                      className="w-full accent-amber-400 cursor-pointer"
                    />
                    <div className="pt-2 border-t border-stone-800 flex items-center justify-between">
                      <span className="text-xs text-stone-400">Calculated Investment:</span>
                      <span className="font-mono-tabular text-base font-semibold text-stone-100">
                        ${billingPeriod === 'annual' ? Math.round(seats * 24 * 0.8) : seats * 24}
                        <span className="text-xs text-stone-400 font-normal">/month</span>
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs text-stone-400">
                    <div className="flex items-center gap-2 text-stone-200">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Single Sign-On (SAML/Okta)</span>
                    </div>
                    <div className="flex items-center gap-2 text-stone-200">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>SOC2 Type II Audit Compliance</span>
                    </div>
                    <div className="flex items-center gap-2 text-stone-200">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Dedicated Postgres Read-Replicas</span>
                    </div>
                    <div className="flex items-center gap-2 text-stone-200">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>99.99% SLA Guaranteed Availability</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeArchetype === 'hospitality' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                  <div>
                    <div className="font-display font-semibold text-lg text-stone-100">MAISON NOIR</div>
                    <div className="text-xs text-stone-400">12-Seat Omakase & Seasonal Cellar</div>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400 text-xs">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span className="font-mono-tabular">Two Michelin Stars</span>
                  </div>
                </div>

                {bookingConfirmed ? (
                  <div className="p-6 bg-stone-900 border border-emerald-500/30 rounded-lg text-center space-y-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                      <Check className="w-5 h-5" />
                    </div>
                    <div className="font-display font-semibold text-base text-stone-100">Table Held for {guests} Guests</div>
                    <p className="text-xs text-stone-400 max-w-sm mx-auto">
                      Chef tasting flight reserved for Friday evening. You will receive SMS verification 24 hours prior to service.
                    </p>
                    <button
                      onClick={() => setBookingConfirmed(false)}
                      className="text-xs text-amber-400 hover:underline pt-2 inline-block"
                    >
                      Modify Reservation
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <div className="space-y-3 bg-stone-900/60 p-4 rounded-lg border border-stone-800">
                      <div className="text-xs text-stone-400">Select Party Size:</div>
                      <div className="flex items-center gap-2">
                        {[1, 2, 4, 6].map(num => (
                          <button
                            key={num}
                            onClick={() => setGuests(num)}
                            className={`w-9 h-9 rounded text-xs font-mono-tabular font-medium border transition-colors ${
                              guests === num
                                ? 'bg-amber-400 text-stone-950 border-amber-400 font-bold'
                                : 'bg-stone-950 border-stone-800 text-stone-300 hover:border-stone-700'
                            }`}
                          >
                            {num}p
                          </button>
                        ))}
                      </div>
                      <div className="text-xs text-stone-400 font-mono-tabular pt-1">
                        Tasting Course: $195/guest · Wine Pairing: $110
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="text-xs text-stone-400">Next Service Availability:</div>
                      <div className="p-3 bg-stone-900 border border-stone-800 rounded flex items-center justify-between text-xs">
                        <span>This Friday, 8:00 PM</span>
                        <span className="text-emerald-400 font-mono-tabular">2 Seats Left</span>
                      </div>
                      <button
                        onClick={() => setBookingConfirmed(true)}
                        className="w-full py-2.5 bg-stone-100 hover:bg-white text-stone-950 text-xs font-semibold rounded transition-colors text-center"
                      >
                        Reserve Table for {guests} {guests === 1 ? 'Guest' : 'Guests'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Bottom Status & Feature Note */}
            <div className="pt-4 mt-4 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-400 font-mono-tabular">
              <span>Status: Fully operational React component</span>
              <span className="text-amber-400">Interactive live prototype</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
