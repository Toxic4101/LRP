import React from 'react';
import { ArrowRight, Recycle, ShieldCheck } from 'lucide-react';

export function CtaBanner() {
  return (
    <section className="bg-gradient-to-r from-[#C9A84C] via-[#deb754] to-[#C9A84C] text-[#080f1a] py-20 px-6 sm:px-12 text-center relative overflow-hidden border-y border-[#C9A84C]/40" id="signup">
      {/* Subtle Vector Watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.06] select-none pointer-events-none">
        <Recycle className="w-[360px] h-[360px] stroke-[1]" />
      </div>

      <div className="relative z-10 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 bg-[#080f1a]/10 rounded-full px-3.5 py-1 text-xs font-bold tracking-widest uppercase mb-4 font-mono-tabular">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Zero-Cost Community Deployment</span>
        </div>

        <h2 className="font-serif-logo text-3xl sm:text-5xl md:text-6xl font-bold text-[#080f1a] leading-tight mb-4">
          Ready to Make a Concrete Environmental Difference?
        </h2>

        <p className="text-base sm:text-lg text-[#080f1a]/85 max-w-lg mx-auto mb-8 font-medium leading-relaxed font-sans">
          Register your address today and our operations team will deliver your complimentary 210-litre recycling drum directly to your gate.
        </p>

        <a
          href="#contact"
          className="inline-flex items-center justify-center gap-2.5 bg-[#080f1a] hover:bg-[#1A2B4A] text-[#C9A84C] font-bold text-sm sm:text-base py-4 px-9 rounded-xl transition-all transform hover:-translate-y-0.5 shadow-2xl tracking-wide group"
        >
          <span>Claim Your Free Drum Today</span>
          <ArrowRight className="w-4 h-4 stroke-[2.5] group-hover:translate-x-1 transition-transform" />
        </a>
      </div>
    </section>
  );
}
