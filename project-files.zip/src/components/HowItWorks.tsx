import React from 'react';
import { ClipboardCheck, Recycle, Truck, CheckCircle2, ArrowRight } from 'lucide-react';

const STEPS = [
  {
    stepIndex: '01',
    icon: ClipboardCheck,
    title: 'Register & Container Drop-Off',
    description: 'Register your household, estate, or commercial premises. Our operations team confirms your service area and delivers your 210L container directly to your gate—completely free of charge.'
  },
  {
    stepIndex: '02',
    icon: Recycle,
    title: 'Single-Stream Filling',
    description: 'Deposit clean beverage cans, plastic containers, fluted cardboard, paper, and glass bottles. No complicated home sorting required—all approved dry recyclables share the drum.'
  },
  {
    stepIndex: '03',
    icon: Truck,
    title: 'Scheduled Route Collection',
    description: 'Our fleet collects on regular designated routes or whenever your container is full. Materials are transported to certified processing centers for 100% ethical recycling diversion.'
  }
];

export function HowItWorks() {
  return (
    <section className="bg-[#080f1a]/75 backdrop-blur-md text-[#F5F0E8] py-24 px-6 sm:px-12 border-t border-[#C9A84C]/20 relative z-10" id="how">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-3 font-mono-tabular">
            <span>Streamlined Operational Workflow</span>
          </div>
          <h2 className="font-serif-logo text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight">
            How The Initiative Works
          </h2>
          <p className="text-sm sm:text-base text-[#F5F0E8]/75 max-w-xl mt-3 font-sans leading-relaxed">
            A frictionless three-stage cycle engineered to maximize community diversion rates without administrative or financial burden.
          </p>
        </div>

        {/* 3 Step Cards with High-Contrast Frosted Backings */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {STEPS.map((step) => {
            const Icon = step.icon;
            return (
              <div
                key={step.stepIndex}
                className="relative bg-[#080f1a]/90 backdrop-blur-lg rounded-2xl p-8 shadow-xl hover:shadow-2xl border border-[#C9A84C]/35 hover:border-[#C9A84C]/65 transition-all duration-300 transform hover:-translate-y-1 flex flex-col justify-between group"
              >
                <div>
                  {/* Step Header: Icon + Number */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#C9A84C]/15 border border-[#C9A84C]/35 flex items-center justify-center text-[#C9A84C] group-hover:bg-[#C9A84C] group-hover:text-[#080f1a] transition-all">
                      <Icon className="w-6 h-6 stroke-[1.8]" />
                    </div>
                    <span className="font-serif-logo text-3xl font-bold text-[#C9A84C]/40 group-hover:text-[#C9A84C] transition-colors">
                      {step.stepIndex}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-3 leading-snug group-hover:text-[#e8c96a] transition-colors">
                    {step.title}
                  </h3>

                  <p className="text-sm text-[#F5F0E8]/80 leading-relaxed font-sans">
                    {step.description}
                  </p>
                </div>

                <div className="mt-8 pt-4 border-t border-[#C9A84C]/20 flex items-center justify-between text-xs">
                  <span className="text-[#C9A84C] font-semibold flex items-center gap-1 font-mono-tabular">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Stage {step.stepIndex}
                  </span>
                  <span className="text-[#F5F0E8]/50 font-mono-tabular">Zero Service Cost</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
