import React from 'react';
import { BrandLogo } from './BrandLogo';

export function SiteFooter() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#030810]/90 backdrop-blur-md py-10 px-6 sm:px-12 border-t border-[#C9A84C]/20 text-xs text-[#F5F0E8]/60 relative z-10">
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <BrandLogo size="sm" />
          <div className="text-center sm:text-left">
            <div>© 2025 Legacy Resource Partners · All rights reserved</div>
            <div className="text-[#C9A84C]/80 text-[11px] mt-0.5">Together we keep our communities clean ♻</div>
          </div>
        </div>

        <div className="flex flex-wrap justify-center items-center gap-6 font-mono-tabular">
          <a href="#how" className="hover:text-[#C9A84C] transition-colors">How It Works</a>
          <a href="#accepts" className="hover:text-[#C9A84C] transition-colors">Accepted Items</a>
          <a href="#audience" className="hover:text-[#C9A84C] transition-colors">Who It's For</a>
          <a href="#leadership" className="hover:text-[#C9A84C] transition-colors">Leadership</a>
          <a href="#contact" className="hover:text-[#C9A84C] transition-colors">Get Drum</a>
          <button 
            onClick={scrollToTop} 
            className="hover:text-[#C9A84C] transition-colors underline cursor-pointer"
          >
            Back to Top ↑
          </button>
        </div>
      </div>
    </footer>
  );
}
