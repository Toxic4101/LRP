import React from 'react';
import { ArrowUpRight, Code, Zap, Shield, Sparkles } from 'lucide-react';

interface HeroProps {
  onStartProject: () => void;
  onExplorePrototypes: () => void;
}

export function Hero({ onStartProject, onExplorePrototypes }: HeroProps) {
  return (
    <section className="relative pt-12 pb-20 px-6 md:px-12 max-w-7xl mx-auto">
      {/* Editorial Kicker & Title */}
      <div className="max-w-4xl">
        <div className="flex items-center gap-2 text-xs text-stone-400 mb-4 font-mono-tabular">
          <span>Creative Web Architecture</span>
          <span aria-hidden="true">·</span>
          <span>Full-Stack Engineering</span>
          <span aria-hidden="true">·</span>
          <span>Bespoke Digital Flagships</span>
        </div>

        <h1 
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-display font-bold tracking-tight text-stone-100 leading-[1.08]"
          style={{ textWrap: 'balance' }}
        >
          Yes, we build extraordinary websites.
        </h1>

        <p className="mt-6 text-base sm:text-lg md:text-xl text-stone-400 max-w-2xl font-body leading-relaxed">
          From high-converting luxury e-commerce and interactive editorial portfolios to complex full-stack SaaS web applications. We design, engineer, and deploy production-grade digital flagships that convert.
        </p>

        {/* Primary and Secondary Action Block */}
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <button
            onClick={onStartProject}
            className="px-6 py-3.5 text-sm font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-amber-400/10 whitespace-nowrap"
          >
            <span>Start Your Website Project</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>

          <button
            onClick={onExplorePrototypes}
            className="px-5 py-3.5 text-sm font-medium text-stone-300 hover:text-stone-100 bg-stone-900 hover:bg-stone-850 border border-stone-800 rounded-lg transition-colors whitespace-nowrap"
          >
            Explore Live Prototypes
          </button>
        </div>

        {/* Claim-to-Proof Metric Adjacency (Zero-Pill, Unboxed Text) */}
        <div className="mt-12 pt-8 border-t border-stone-800/80 grid grid-cols-2 sm:grid-cols-4 gap-6">
          <div>
            <div className="text-2xl sm:text-3xl font-display font-bold text-stone-100 font-mono-tabular">48+</div>
            <div className="text-xs text-stone-400 mt-1">Live Production Launches</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-display font-bold text-stone-100 font-mono-tabular">0.38s</div>
            <div className="text-xs text-stone-400 mt-1">Median First Paint Latency</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-display font-bold text-stone-100 font-mono-tabular">+140%</div>
            <div className="text-xs text-stone-400 mt-1">Average Conversion Lift</div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-display font-bold text-stone-100 font-mono-tabular">100%</div>
            <div className="text-xs text-stone-400 mt-1">Custom Engineered Code</div>
          </div>
        </div>
      </div>

      {/* Hero Visual Anchor (Single Dominant Carrier 16:9) */}
      <div className="mt-14 relative rounded-xl overflow-hidden border border-stone-800 shadow-2xl bg-stone-900 aspect-16/9 max-h-[560px] w-full">
        <img
          src="/src/assets/images/hero_creative_studio_1791403260110.jpg"
          alt="Vanguard Studio architectural workspace and digital production laboratory"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center"
          onError={(e) => {
            // Zero-broken image policy fallback
            (e.currentTarget as HTMLElement).style.display = 'none';
          }}
        />

        {/* Measured Contrast Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent pointer-events-none" />

        {/* In-Frame Context Overlay */}
        <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4 pointer-events-none">
          <div className="space-y-1">
            <div className="text-xs font-mono-tabular text-amber-400 font-medium">STUDIO ATELIER & ARCHITECTURE</div>
            <div className="text-sm md:text-base font-semibold text-stone-100">
              Where bespoke design systems meet rigorous TypeScript engineering.
            </div>
          </div>
          <div className="text-xs text-stone-400 font-mono-tabular hidden sm:block">
            Geneva · London · Helsinki
          </div>
        </div>
      </div>
    </section>
  );
}
