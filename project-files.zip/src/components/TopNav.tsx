import React from 'react';
import { BrandLogo } from './BrandLogo';
import { ChacoGoldenSpider } from './ChacoGoldenSpider';
import { ArrowRight } from 'lucide-react';

export function TopNav() {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#080f1a]/85 backdrop-blur-md border-b border-[#C9A84C]/30 px-6 sm:px-12 py-3.5 transition-all shadow-xl shadow-black/70">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Upper Top Left: Chaco Golden Spider Symbol & Brand Logo */}
        <div className="flex items-center gap-3">
          <ChacoGoldenSpider size={36} />
          <div className="hidden xs:block h-7 w-[1px] bg-gradient-to-b from-transparent via-[#C9A84C]/40 to-transparent" />
          <a href="#" className="hover:opacity-90 transition-opacity">
            <BrandLogo size="md" />
          </a>
        </div>

        {/* Navigation Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-bold uppercase tracking-wider text-[#F5F0E8]">
          <a href="#how" className="hover:text-[#C9A84C] transition-colors">
            How It Works
          </a>
          <a href="#accepts" className="hover:text-[#C9A84C] transition-colors">
            What We Accept
          </a>
          <a href="#audience" className="hover:text-[#C9A84C] transition-colors">
            Who It's For
          </a>
          <a href="#leadership" className="hover:text-[#C9A84C] transition-colors">
            Leadership
          </a>
          <a href="#contact" className="hover:text-[#C9A84C] transition-colors">
            Sign Up
          </a>
        </nav>

        {/* Action Group */}
        <div className="flex items-center gap-3">
          {/* Top Bar CTA */}
          <a
            href="#contact"
            className="bg-[#C9A84C] hover:bg-[#e8c96a] text-[#080f1a] font-bold text-xs sm:text-sm px-4 sm:px-5 py-2.5 rounded-lg transition-colors tracking-wide shadow-sm shadow-[#C9A84C]/20 whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <span>Claim Free Drum</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
}
