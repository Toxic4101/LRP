import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'inline' | 'badge';
  layout?: 'horizontal' | 'vertical';
}

/**
 * Official Logo for Legacy Resource Partners Recycling
 * Accurately vectorized from the brand's official emblem:
 * - Golden architectural gate arch & fence
 * - Three-arrow circular recycling loop with organic leaves & veins
 * - Paper sheet, cardboard carton & bottle in the core
 * - Authoritative serif "LEGACY" wordmark
 * - Divider bar & "RESOURCE PARTNERS RECYCLING"
 */
export function BrandLogo({
  className = '',
  size = 'md',
  variant = 'inline',
  layout = 'horizontal'
}: BrandLogoProps) {
  const isSm = size === 'sm';
  const isMd = size === 'md';
  const isLg = size === 'lg';
  const isXl = size === 'xl';

  const isVertical = layout === 'vertical' || isLg || isXl;

  // The Emblem SVG
  const renderEmblem = (widthClass: string, heightClass: string, onLightBg: boolean = false) => {
    const goldColor = '#C9A84C';
    const navyColor = onLightBg ? '#0F2240' : '#1A2B4A';
    const arrowFill = onLightBg ? '#0F2240' : '#e8c96a';
    const leafFill = onLightBg ? '#0F2240' : '#C9A84C';
    const leafVein = onLightBg ? '#C9A84C' : '#080f1a';
    const centerItems = onLightBg ? '#C9A84C' : '#F5F0E8';

    return (
      <svg
        viewBox="0 0 200 190"
        className={`${widthClass} ${heightClass} shrink-0 select-none`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* ── 1. ARCHED GATE ARCHITECTURE (GOLD) ── */}
        <g stroke={goldColor} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
          {/* Outer Arch */}
          <path d="M 36 170 L 36 86 C 36 42 66 18 100 18 C 134 18 164 42 164 86 L 164 170" />
          {/* Inner Arch Accent */}
          <path d="M 46 170 L 46 90 C 46 54 70 30 100 30 C 130 30 154 54 154 90 L 154 170" strokeWidth="1.5" opacity="0.75" />
          
          {/* Base Horizontal Rails */}
          <line x1="28" y1="170" x2="172" y2="170" strokeWidth="4.5" />
          <line x1="34" y1="180" x2="166" y2="180" strokeWidth="3" />

          {/* Stepped Base Feet */}
          <path d="M 28 170 L 28 184 L 38 184" strokeWidth="2.5" />
          <path d="M 172 170 L 172 184 L 162 184" strokeWidth="2.5" />

          {/* Vertical Gate Picket Bars */}
          <line x1="42" y1="152" x2="42" y2="170" strokeWidth="2.5" />
          <line x1="52" y1="140" x2="52" y2="170" strokeWidth="2.5" />
          <line x1="62" y1="148" x2="62" y2="170" strokeWidth="2.5" />
          <line x1="138" y1="148" x2="138" y2="170" strokeWidth="2.5" />
          <line x1="148" y1="140" x2="148" y2="170" strokeWidth="2.5" />
          <line x1="158" y1="152" x2="158" y2="170" strokeWidth="2.5" />
        </g>

        {/* ── 2. CIRCULAR RECYCLING ARROWS & LEAVES ── */}
        <g id="recycling-symbol">
          {/* Top-Right Curved Arrow */}
          <path
            d="M 85 28 C 115 25 142 42 148 72 L 140 76 L 158 92 L 162 68 L 150 72 C 144 48 120 32 92 34 Z"
            fill={arrowFill}
          />

          {/* Bottom Curved Arrow */}
          <path
            d="M 145 125 C 135 152 105 166 75 156 L 78 147 L 54 148 L 68 168 L 72 159 C 100 168 130 152 140 128 Z"
            fill={arrowFill}
          />

          {/* Left Upward Curved Arrow */}
          <path
            d="M 52 110 C 42 80 56 48 84 38 L 84 46 L 98 28 L 74 24 L 78 33 C 54 44 42 72 48 102 Z"
            fill={arrowFill}
          />

          {/* Stylized Leaf Overlay 1 (Top Left) */}
          <path
            d="M 68 45 C 55 58 58 80 74 78 C 84 72 88 56 68 45 Z"
            fill={leafFill}
          />
          <path d="M 68 45 Q 70 65 74 78" stroke={leafVein} strokeWidth="1.5" strokeLinecap="round" />
          <path d="M 68 56 Q 63 60 61 65" stroke={leafVein} strokeWidth="1" strokeLinecap="round" />
          <path d="M 71 63 Q 76 66 79 70" stroke={leafVein} strokeWidth="1" strokeLinecap="round" />

          {/* Stylized Leaf Overlay 2 (Right) */}
          <path
            d="M 148 75 C 162 86 160 110 144 114 C 132 112 126 95 148 75 Z"
            fill={leafFill}
          />
          <path d="M 148 75 Q 146 95 144 114" stroke={leafVein} strokeWidth="1.5" strokeLinecap="round" />
          <path d="M 148 88 Q 155 93 158 98" stroke={leafVein} strokeWidth="1" strokeLinecap="round" />
          <path d="M 145 96 Q 138 100 135 104" stroke={leafVein} strokeWidth="1" strokeLinecap="round" />

          {/* Stylized Leaf Overlay 3 (Bottom) */}
          <path
            d="M 105 148 C 88 152 76 138 86 125 C 96 120 112 130 105 148 Z"
            fill={leafFill}
          />
          <path d="M 105 148 Q 94 136 86 125" stroke={leafVein} strokeWidth="1.5" strokeLinecap="round" />
        </g>

        {/* ── 3. CENTER RECYCLABLE ITEMS (PAPER, CARTON, BOTTLE) ── */}
        <g fill={centerItems} stroke={centerItems} strokeLinecap="round" strokeLinejoin="round">
          {/* Top Item: Paper Document with text lines & folded dog-ear */}
          <path d="M 94 66 L 106 66 L 112 72 L 112 88 L 94 88 Z" fill="none" strokeWidth="1.5" />
          <path d="M 106 66 L 106 72 L 112 72" fill="none" strokeWidth="1.5" />
          <line x1="97" y1="74" x2="105" y2="74" strokeWidth="1.2" />
          <line x1="97" y1="78" x2="108" y2="78" strokeWidth="1.2" />
          <line x1="97" y1="82" x2="106" y2="82" strokeWidth="1.2" />

          {/* Bottom Left: Carton / Packaging Box */}
          <path d="M 76 98 L 86 92 L 96 98 L 86 104 Z" fill="none" strokeWidth="1.4" />
          <path d="M 76 98 L 76 108 L 86 114 L 86 104" fill="none" strokeWidth="1.4" />
          <path d="M 86 114 L 96 108 L 96 98" fill="none" strokeWidth="1.4" />

          {/* Bottom Right: Plastic Beverage Bottle with Ridges */}
          <rect x="108" y="94" width="4" height="4" rx="0.5" strokeWidth="1" />
          <path d="M 107 98 L 113 98 L 115 103 L 115 116 L 105 116 L 105 103 Z" fill="none" strokeWidth="1.4" />
          <line x1="106" y1="106" x2="114" y2="106" strokeWidth="1" />
          <line x1="106" y1="110" x2="114" y2="110" strokeWidth="1" />
        </g>
      </svg>
    );
  };

  // If badge variant is chosen: renders the luxury cream textured card matching the uploaded file
  if (variant === 'badge') {
    return (
      <div className={`inline-flex flex-col items-center bg-[#F7F4EC] text-[#0F2240] p-6 sm:p-8 rounded-2xl shadow-2xl border-2 border-[#C9A84C]/40 ${className}`}>
        {renderEmblem('w-28 sm:w-36', 'h-28 sm:h-36', true)}
        
        <div className="mt-4 text-center">
          <div className="font-serif-logo text-3xl sm:text-4xl font-bold tracking-[0.06em] text-[#0F2240] leading-tight">
            LEGACY
          </div>
          <div className="w-full h-[2px] bg-[#0F2240] my-1.5 opacity-90" />
          <div className="font-sans font-extrabold text-[11px] sm:text-xs tracking-[0.16em] uppercase text-[#0F2240]">
            RESOURCE PARTNERS
          </div>
          <div className="font-sans font-bold text-[10px] sm:text-[11px] tracking-[0.22em] uppercase text-[#0F2240] mt-0.5">
            RECYCLING
          </div>
        </div>
      </div>
    );
  }

  // Inline layout (for TopNav and Form header)
  return (
    <div className={`flex ${isVertical ? 'flex-col items-center text-center' : 'items-center gap-3.5'} select-none ${className}`}>
      {renderEmblem(
        isSm ? 'w-10' : isMd ? 'w-12 sm:w-14' : isLg ? 'w-20' : 'w-24 sm:w-28',
        isSm ? 'h-10' : isMd ? 'h-12 sm:h-14' : isLg ? 'h-20' : 'h-24 sm:h-28',
        false
      )}

      <div className={`flex flex-col ${isVertical ? 'items-center mt-3' : 'items-start justify-center'}`}>
        <div 
          className={`font-serif-logo font-bold tracking-[0.06em] text-white leading-none ${
            isSm ? 'text-lg' : isMd ? 'text-2xl' : isLg ? 'text-3xl sm:text-4xl' : 'text-4xl sm:text-5xl'
          }`}
        >
          LEGACY
        </div>

        {/* Crisp divider bar */}
        <div className={`h-[1.5px] bg-[#C9A84C] my-1 w-full opacity-80`} />

        <div 
          className={`font-sans font-extrabold tracking-[0.16em] uppercase text-[#C9A84C] leading-tight ${
            isSm ? 'text-[8px]' : isMd ? 'text-[10px]' : isLg ? 'text-xs' : 'text-sm'
          }`}
        >
          RESOURCE PARTNERS
        </div>

        <div 
          className={`font-sans font-bold tracking-[0.24em] uppercase text-[#F5F0E8]/85 leading-tight ${
            isSm ? 'text-[7px]' : isMd ? 'text-[9px]' : isLg ? 'text-[10px]' : 'text-xs'
          }`}
        >
          RECYCLING
        </div>
      </div>
    </div>
  );
}
