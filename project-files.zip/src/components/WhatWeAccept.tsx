import React, { useState } from 'react';
import { Search, CheckCircle2, AlertTriangle, Layers, FileText, Package, Box, Recycle, ShieldAlert } from 'lucide-react';

interface RecyclableCategory {
  id: string;
  name: string;
  grade: string;
  details: string;
  iconName: 'metal' | 'glass' | 'bottle' | 'container' | 'cardboard' | 'paper' | 'jar' | 'carton' | 'tin' | 'bucket' | 'wrap' | 'general';
}

const CATEGORIES: RecyclableCategory[] = [
  { id: '1', name: 'Aluminium & Tin Cans', grade: 'Metals', details: 'Rinsed food tins, beverage cans, pet food tins', iconName: 'metal' },
  { id: '2', name: 'Glass Bottles', grade: 'Flint / Amber Glass', details: 'Wine bottles, beer bottles, soft drink glass', iconName: 'glass' },
  { id: '3', name: 'Plastic Bottles (PET/HDPE)', grade: 'Code 1 & 2', details: 'Water bottles, soda bottles, milk jugs, detergent', iconName: 'bottle' },
  { id: '4', name: 'Rigid Plastic Containers', grade: 'Code 4 & 5', details: 'Yoghurt tubs, ice-cream tubs, cosmetic bottles', iconName: 'container' },
  { id: '5', name: 'Corrugated Cardboard', grade: 'Kraft / Fluted', details: 'Flattened delivery cartons, appliance boxes', iconName: 'cardboard' },
  { id: '6', name: 'Paper & Newsprint', grade: 'Fibre Grade A', details: 'Magazines, newspapers, office paper, envelopes', iconName: 'paper' },
  { id: '7', name: 'Food & Pantry Jars', grade: 'Clear Container Glass', details: 'Preserve jars, coffee jars, condiment jars', iconName: 'jar' },
  { id: '8', name: 'Liquid Cartons (Tetra Pak)', grade: 'Aseptic Composite', details: 'Juice cartons, long-life milk cartons', iconName: 'carton' },
  { id: '9', name: 'Clean Steel & Dry Tins', grade: 'Ferrous Metals', details: 'Dry paint tins, decorative biscuit tins, tea tins', iconName: 'tin' },
  { id: '10', name: 'Plastic Buckets & Pails', grade: 'Heavy Polypropylene', details: 'Storage tubs, utility buckets, plastic crates', iconName: 'bucket' },
  { id: '11', name: 'Clean Plastic Wrap & Film', grade: 'LDPE Film', details: 'Pallet shrink wrap, clean bubble wrap, air pillows', iconName: 'wrap' },
  { id: '12', name: 'Dry Clean Recyclables', grade: 'Mixed Dry Stream', details: 'Clean metals, mixed recyclable domestic packaging', iconName: 'general' },
];

export function WhatWeAccept() {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = CATEGORIES.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.grade.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="bg-[#080f1a]/75 backdrop-blur-md py-24 px-6 sm:px-12 text-[#F5F0E8] border-t border-[#C9A84C]/20 relative z-10" id="accepts">
      <div className="max-w-5xl mx-auto">
        {/* Header with Search */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-3 font-mono-tabular">
              <span>Material Acceptance Guidelines</span>
            </div>
            <h2 className="font-serif-logo text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight">
              Accepted Material Stream
            </h2>
            <p className="text-sm text-[#F5F0E8]/75 max-w-xl mt-2 font-sans">
              All approved commodities are processed through verified secondary material recovery streams.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#C9A84C]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recyclable item (e.g. cans, jars)..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/40 focus:border-[#C9A84C] rounded-xl text-sm text-[#F5F0E8] placeholder-[#F5F0E8]/40 outline-none transition-colors"
            />
          </div>
        </div>

        {/* 12 Material Cards Grid with High Legibility Backings */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((cat) => (
            <div
              key={cat.id}
              className="bg-[#080f1a]/90 backdrop-blur-md hover:bg-[#080f1a] border border-[#C9A84C]/25 hover:border-[#C9A84C]/60 rounded-xl p-5 transition-all duration-200 flex flex-col justify-between group shadow-lg hover:shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-mono-tabular font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-[#C9A84C]/15 text-[#C9A84C] border border-[#C9A84C]/30">
                    {cat.grade}
                  </span>
                  <CheckCircle2 className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform" />
                </div>

                <h3 className="text-sm font-bold text-white group-hover:text-[#e8c96a] transition-colors leading-snug mb-1.5">
                  {cat.name}
                </h3>

                <p className="text-xs text-[#F5F0E8]/70 leading-relaxed font-sans">
                  {cat.details}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#F5F0E8]/50 font-mono-tabular">
                <span>Verified Stream</span>
                <span className="text-[#C9A84C] font-semibold">Accepted ✓</span>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filtered.length === 0 && (
          <div className="text-center py-12 bg-[#080f1a]/95 backdrop-blur-lg rounded-xl border border-[#C9A84C]/35 p-8">
            <AlertTriangle className="w-8 h-8 text-[#C9A84C] mx-auto mb-2 opacity-90" />
            <div className="text-base font-semibold text-white">Item query not in standard index</div>
            <p className="text-xs text-[#F5F0E8]/70 mt-1 max-w-md mx-auto">
              If the item consists of clean plastic, tinplate, cardboard, paper, or glass, it is suitable for drum collection. Contact our operations desk for special bulk materials.
            </p>
          </div>
        )}

        {/* Quality Standards & Contamination Policy */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/30 rounded-xl flex items-start gap-3.5 shadow-lg">
            <CheckCircle2 className="w-5 h-5 text-[#C9A84C] shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-[#F5F0E8]/85">
              <strong className="text-white block font-semibold mb-0.5">Preparation Protocol:</strong>
              A brief water rinse prevents pest attraction and preserves commodity cleanliness. Flattening cardboard maximizes your container capacity.
            </div>
          </div>

          <div className="p-5 bg-[#080f1a]/90 backdrop-blur-md border border-red-500/35 rounded-xl flex items-start gap-3.5 shadow-lg">
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-[#F5F0E8]/85">
              <strong className="text-white block font-semibold mb-0.5">Contamination Exceptions:</strong>
              No organic wet food waste, medical supplies, hazardous chemicals, lightbulbs, or disposable nappies may be placed in the collection drum.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
