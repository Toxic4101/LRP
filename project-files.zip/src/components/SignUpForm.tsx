import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { CheckCircle2, Phone, Mail, MessageSquare, AlertCircle, ArrowRight, ShieldCheck, Clock } from 'lucide-react';

type ContactOption = 'wa-armand' | 'wa-braam' | 'wa-danielle' | 'call-armand' | 'call-braam' | 'call-danielle' | 'email';
type SignUpType = 'Household' | 'Business' | 'School / Community';

export function SignUpForm() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [signUpType, setSignUpType] = useState<SignUpType>('Household');
  const [contactMethod, setContactMethod] = useState<ContactOption>('wa-armand');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [generatedMessage, setGeneratedMessage] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!name.trim() || !phone.trim() || !address.trim()) {
      setErrorMsg('Please complete all required fields (Name, Phone/WhatsApp, and Address or Area).');
      return;
    }

    const rawMessage = `Hi Legacy Resource Partners!\n\nI'd like to sign up for a free drum.\n\nName: ${name}\nPhone: ${phone}\nAddress: ${address}\nType: ${signUpType}`;
    const encoded = encodeURIComponent(rawMessage);
    setGeneratedMessage(rawMessage);
    setIsSuccess(true);

    // Route based on preferred contact
    try {
      if (contactMethod === 'wa-armand') {
        window.open(`https://wa.me/27735366708?text=${encoded}`, '_blank');
      } else if (contactMethod === 'wa-braam') {
        window.open(`https://wa.me/27794196204?text=${encoded}`, '_blank');
      } else if (contactMethod === 'wa-danielle') {
        window.open(`https://wa.me/27650747176?text=${encoded}`, '_blank');
      } else if (contactMethod === 'call-armand') {
        window.location.href = 'tel:0735366708';
      } else if (contactMethod === 'call-braam') {
        window.location.href = 'tel:0794196204';
      } else if (contactMethod === 'call-danielle') {
        window.location.href = 'tel:0650747176';
      } else if (contactMethod === 'email') {
        window.location.href = `mailto:legacyresourcepartners@outlook.com?subject=Free%20Drum%20Sign-Up&body=${encoded}`;
      }
    } catch {
      // In case iframe blocks popup, success screen provides instant action buttons
    }
  };

  const getEncodedLink = (phoneNum: string) => {
    const encoded = encodeURIComponent(
      generatedMessage ||
      `Hi Legacy Resource Partners, I would like to request a free collection drum.\n\nName: ${name || 'Prospective Partner'}\nArea: ${address || 'Local Suburb'}`
    );
    return `https://wa.me/${phoneNum}?text=${encoded}`;
  };

  return (
    <section className="bg-[#080f1a]/75 backdrop-blur-md py-24 px-6 sm:px-12 relative z-10 border-t border-[#C9A84C]/20" id="contact">
      <div className="max-w-xl mx-auto">
        {/* Operational Status & Section Header */}
        <div className="text-center mb-10 flex flex-col items-center">
          {/* Active Dispatch Status Badge */}
          <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-5 shadow-xs font-mono-tabular">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Operational Route Active · 210L Units In Stock</span>
          </div>

          <h2 className="font-serif-logo text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight mb-3">
            Claim Your Free Collection Drum
          </h2>
          
          <p className="text-sm sm:text-base text-[#F5F0E8]/80 max-w-lg mx-auto leading-relaxed font-sans mb-8">
            Complete the formal dispatch form below. Our logistics coordinator will verify your route and arrange gate-side delivery with zero fees.
          </p>

          {/* 3-Pillar Service Assurance Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full text-left mb-4">
            <div className="p-3.5 rounded-xl bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/30 flex items-start gap-3 shadow-md">
              <ShieldCheck className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-white leading-snug">Zero-Cost Guarantee</div>
                <div className="text-[11px] text-[#F5F0E8]/70 mt-0.5 leading-tight">No drop-off or collection charge ever</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/30 flex items-start gap-3 shadow-md">
              <Clock className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-white leading-snug">3–5 Day Dispatch</div>
                <div className="text-[11px] text-[#F5F0E8]/70 mt-0.5 leading-tight">Direct gate placement on confirmation</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/30 flex items-start gap-3 shadow-md">
              <CheckCircle2 className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-white leading-snug">Single-Stream Simplicity</div>
                <div className="text-[11px] text-[#F5F0E8]/70 mt-0.5 leading-tight">All clean recyclables in one container</div>
              </div>
            </div>
          </div>
        </div>

        {isSuccess ? (
          <div className="bg-[#080f1a]/95 backdrop-blur-lg border border-[#C9A84C]/50 rounded-2xl p-8 sm:p-10 text-center space-y-6 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-[#C9A84C]/20 border border-[#C9A84C]/50 flex items-center justify-center mx-auto text-[#C9A84C]">
              <CheckCircle2 className="w-8 h-8 stroke-[2.2]" />
            </div>

            <div>
              <h3 className="font-serif-logo text-2xl sm:text-3xl font-bold text-[#C9A84C] leading-snug mb-2">
                Registration Confirmed
              </h3>
              <p className="text-sm text-[#F5F0E8]/85 leading-relaxed font-sans">
                Thank you, <strong className="text-white">{name}</strong>. Your request for a free 210L container at <strong className="text-white">{address}</strong> has been logged with operations. We will be in touch shortly to confirm delivery.
              </p>
            </div>

            {/* Direct WhatsApp Action Buttons (Armand, Braam, Danielle) */}
            <div className="pt-2 space-y-3">
              <div className="text-xs text-[#F5F0E8]/70 uppercase tracking-wider font-mono-tabular">
                Connect Directly With Operations:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <a
                  href={getEncodedLink('27735366708')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/50 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
                  <span className="truncate">WhatsApp Armand</span>
                </a>
                <a
                  href={getEncodedLink('27794196204')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/50 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
                  <span className="truncate">WhatsApp Braam</span>
                </a>
                <a
                  href={getEncodedLink('27650747176')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/50 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
                  <span className="truncate">WhatsApp Danielle</span>
                </a>
              </div>
            </div>

            <div className="pt-4 border-t border-[#C9A84C]/20">
              <button
                onClick={() => {
                  setIsSuccess(false);
                  setName('');
                  setPhone('');
                  setAddress('');
                }}
                className="text-xs text-[#C9A84C] hover:text-[#e8c96a] underline cursor-pointer"
              >
                Enroll another premises or household
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-[#080f1a]/94 backdrop-blur-lg border border-[#C9A84C]/35 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-5">
            {/* Name and Phone Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#F5F0E8]/80 uppercase tracking-wider mb-1.5 font-mono-tabular">
                  Full Name / Contact Person *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Johan Van Der Merwe"
                  className="w-full bg-[#080f1a] border border-[#C9A84C]/35 focus:border-[#C9A84C] rounded-xl px-4 py-3 text-sm text-[#F5F0E8] placeholder-[#F5F0E8]/40 outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#F5F0E8]/80 uppercase tracking-wider mb-1.5 font-mono-tabular">
                  Phone / WhatsApp Number *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 072 000 0000"
                  className="w-full bg-[#080f1a] border border-[#C9A84C]/35 focus:border-[#C9A84C] rounded-xl px-4 py-3 text-sm text-[#F5F0E8] placeholder-[#F5F0E8]/40 outline-none transition-colors"
                />
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold text-[#F5F0E8]/80 uppercase tracking-wider mb-1.5 font-mono-tabular">
                Street Address & Suburb / Area *
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Street name, number, estate name, or suburb"
                className="w-full bg-[#080f1a] border border-[#C9A84C]/35 focus:border-[#C9A84C] rounded-xl px-4 py-3 text-sm text-[#F5F0E8] placeholder-[#F5F0E8]/40 outline-none transition-colors"
              />
            </div>

            {/* Sign Up As */}
            <div>
              <label className="block text-xs font-semibold text-[#F5F0E8]/80 uppercase tracking-wider mb-2 font-mono-tabular">
                Sector Classification *
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Household', 'Business', 'School / Community'] as SignUpType[]).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setSignUpType(type)}
                    className={`py-2.5 px-3 rounded-lg border text-xs font-medium text-center transition-all cursor-pointer ${
                      signUpType === type
                        ? 'bg-[#C9A84C] text-[#080f1a] font-bold border-[#C9A84C]'
                        : 'bg-[#080f1a] text-[#F5F0E8]/85 border-[#C9A84C]/25 hover:border-[#C9A84C]/50'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Preferred Contact Method */}
            <div>
              <label className="block text-xs font-semibold text-[#F5F0E8]/80 uppercase tracking-wider mb-2 font-mono-tabular">
                Preferred Operational Contact Channel *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* Armand WA */}
                <button
                  type="button"
                  onClick={() => setContactMethod('wa-armand')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'wa-armand'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">WhatsApp Armand</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">073 536 6708</div>
                  </div>
                </button>

                {/* Braam WA */}
                <button
                  type="button"
                  onClick={() => setContactMethod('wa-braam')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'wa-braam'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">WhatsApp Braam</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">079 419 6204</div>
                  </div>
                </button>

                {/* Danielle WA */}
                <button
                  type="button"
                  onClick={() => setContactMethod('wa-danielle')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'wa-danielle'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">WhatsApp Danielle</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">+27 65 074 7176</div>
                  </div>
                </button>

                {/* Call Danielle */}
                <button
                  type="button"
                  onClick={() => setContactMethod('call-danielle')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'call-danielle'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Call Danielle</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">065 074 7176</div>
                  </div>
                </button>

                {/* Call Armand */}
                <button
                  type="button"
                  onClick={() => setContactMethod('call-armand')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'call-armand'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Call Armand</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">073 536 6708</div>
                  </div>
                </button>

                {/* Call Braam */}
                <button
                  type="button"
                  onClick={() => setContactMethod('call-braam')}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'call-braam'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Call Braam</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">079 419 6204</div>
                  </div>
                </button>

                {/* Email Option */}
                <button
                  type="button"
                  onClick={() => setContactMethod('email')}
                  className={`sm:col-span-2 flex items-center gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    contactMethod === 'email'
                      ? 'bg-[#C9A84C]/20 border-[#C9A84C] shadow-sm'
                      : 'bg-[#080f1a] border-[#C9A84C]/25 hover:border-[#C9A84C]/45'
                  }`}
                >
                  <Mail className="w-4 h-4 text-[#C9A84C] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-white">Direct Email Dispatch</div>
                    <div className="text-[11px] text-[#F5F0E8]/70 font-mono-tabular">legacyresourcepartners@outlook.com</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Error Banner */}
            {errorMsg && (
              <div className="bg-red-500/15 border border-red-500/40 rounded-xl p-3.5 flex items-center gap-2.5 text-xs text-red-300">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-[#C9A84C] hover:bg-[#e8c96a] text-[#080f1a] font-bold text-sm sm:text-base py-4 rounded-xl transition-all shadow-xl shadow-[#C9A84C]/20 flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <span>Submit Drum Request</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>
        )}

        {/* Divider */}
        <div className="flex items-center gap-4 my-10">
          <div className="flex-1 h-px bg-[#C9A84C]/20" />
          <span className="text-xs text-[#F5F0E8]/50 uppercase tracking-widest font-mono-tabular">
            Direct Communications Desk
          </span>
          <div className="flex-1 h-px bg-[#C9A84C]/20" />
        </div>

        {/* Direct WhatsApp Callouts (Armand, Braam, Danielle) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          <a
            href="https://wa.me/27735366708?text=Hi%20Legacy%20Resource%20Partners%2C%20I%27d%20like%20a%20free%20drum%20please."
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/45 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
          >
            <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
            <span className="truncate">WhatsApp Armand</span>
          </a>

          <a
            href="https://wa.me/27794196204?text=Hi%20Legacy%20Resource%20Partners%2C%20I%27d%20like%20a%20free%20drum%20please."
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/45 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
          >
            <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
            <span className="truncate">WhatsApp Braam</span>
          </a>

          <a
            href="https://wa.me/27650747176?text=Hi%20Legacy%20Resource%20Partners%2C%20I%27d%20like%20a%20free%20drum%20please."
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-[#0c182c] hover:bg-[#152744] border border-[#C9A84C]/45 hover:border-[#C9A84C] text-[#F5F0E8] font-bold text-xs py-3.5 px-3 rounded-xl transition-all shadow-md cursor-pointer group"
          >
            <MessageSquare className="w-4 h-4 text-[#C9A84C] group-hover:scale-110 transition-transform shrink-0" />
            <span className="truncate">WhatsApp Danielle</span>
          </a>
        </div>

        {/* Trust & Dispatch Commitment */}
        <div className="p-4 rounded-xl bg-[#080f1a]/90 backdrop-blur-md border border-[#C9A84C]/25 text-center text-xs text-[#F5F0E8]/70 space-y-1 shadow-md">
          <div className="flex items-center justify-center gap-2 text-[#C9A84C] font-semibold">
            <Clock className="w-3.5 h-3.5" />
            <span>Rapid Route Fulfillment: 3–5 Business Days</span>
          </div>
          <p className="font-mono-tabular text-[11px] text-[#F5F0E8]/50">
            Official Email: <a href="mailto:legacyresourcepartners@outlook.com" className="text-[#C9A84C] hover:underline">legacyresourcepartners@outlook.com</a>
          </p>
        </div>
      </div>
    </section>
  );
}
