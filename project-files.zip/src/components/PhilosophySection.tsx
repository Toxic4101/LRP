import React from 'react';
import { Layers, ShieldCheck, Zap, Sparkles } from 'lucide-react';

export function PhilosophySection() {
  return (
    <section id="philosophy" className="py-24 px-6 md:px-12 max-w-7xl mx-auto border-t border-stone-800">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-2 text-xs text-stone-400 mb-2 font-mono-tabular">
            <span>Engineering Discipline</span>
            <span aria-hidden="true">·</span>
            <span>Zero-AI-Slop Code</span>
            <span aria-hidden="true">·</span>
            <span>Crafted by Hand</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
            The Four Tenets of Vanguard Web Architecture
          </h2>
          <p className="mt-4 text-stone-400 text-sm md:text-base font-body leading-relaxed">
            The modern web is inundated with cookie-cutter templates, sluggish JavaScript bundles, and bloated animations. We construct websites according to an architectural standard of restraint, performance, and durability.
          </p>
        </div>

        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 bg-stone-900/40 border border-stone-800 rounded-xl">
            <div className="flex items-baseline gap-3 mb-2">
              <span className="font-mono-tabular text-amber-400 font-bold text-sm">01</span>
              <h3 className="font-display font-semibold text-stone-100 text-base">Sub-500ms First Contentful Paint</h3>
            </div>
            <p className="text-xs sm:text-sm text-stone-400 font-body leading-relaxed">
              Every asset is compressed, critical styles are inlined, and scripts are treeshaken. Your visitors never look at loading spinners or layout shifts.
            </p>
          </div>

          <div className="p-6 bg-stone-900/40 border border-stone-800 rounded-xl">
            <div className="flex items-baseline gap-3 mb-2">
              <span className="font-mono-tabular text-amber-400 font-bold text-sm">02</span>
              <h3 className="font-display font-semibold text-stone-100 text-base">Mathematical Layout & Typographic Hierarchy</h3>
            </div>
            <p className="text-xs sm:text-sm text-stone-400 font-body leading-relaxed">
              Container padding strictly exceeds child spacing. Headline widths adhere to optical reading measures without awkward orphan words or broken line breaks.
            </p>
          </div>

          <div className="p-6 bg-stone-900/40 border border-stone-800 rounded-xl">
            <div className="flex items-baseline gap-3 mb-2">
              <span className="font-mono-tabular text-amber-400 font-bold text-sm">03</span>
              <h3 className="font-display font-semibold text-stone-100 text-base">Every Control Has a Working Handler</h3>
            </div>
            <p className="text-xs sm:text-sm text-stone-400 font-body leading-relaxed">
              No mock links that lead nowhere, no dead click handlers, and no empty placeholder shells. Every component is completely functional.
            </p>
          </div>

          <div className="p-6 bg-stone-900/40 border border-stone-800 rounded-xl">
            <div className="flex items-baseline gap-3 mb-2">
              <span className="font-mono-tabular text-amber-400 font-bold text-sm">04</span>
              <h3 className="font-display font-semibold text-stone-100 text-base">Accessibility (WCAG AA) & Touch Ergonomics</h3>
            </div>
            <p className="text-xs sm:text-sm text-stone-400 font-body leading-relaxed">
              Touch targets maintain a minimum 44px tap zone on mobile viewports. Color contrast satisfies 4.5:1 ratios across all light and dark themes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
