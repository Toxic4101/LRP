import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, Clock, Mail, User, Building2, MessageSquare } from 'lucide-react';

interface ContactSectionProps {
  initialArchetype?: string;
  initialEstimate?: {
    archetype: string;
    total: number;
    weeks: number;
  } | null;
}

export function ContactSection({ initialArchetype, initialEstimate }: ContactSectionProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [archetype, setArchetype] = useState(initialArchetype || 'Custom E-Commerce');
  const [timeline, setTimeline] = useState('2-4 Weeks');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ name?: string; email?: string }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submissionReceipt, setSubmissionReceipt] = useState<{ id: string; timestamp: string } | null>(null);

  useEffect(() => {
    if (initialArchetype) {
      setArchetype(initialArchetype);
    }
    if (initialEstimate) {
      setNotes(`Configured via Estimator: ${initialEstimate.archetype} (~$${initialEstimate.total.toLocaleString()}, ${initialEstimate.weeks} weeks delivery).`);
    }
  }, [initialArchetype, initialEstimate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { name?: string; email?: string } = {};

    if (!name.trim()) {
      newErrors.name = 'Please provide your name or brand title';
    }

    if (!email.trim() || !email.includes('@') || !email.includes('.')) {
      newErrors.email = 'Please provide a valid work email address';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsSubmitted(true);
    setSubmissionReceipt({
      id: `VG-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
  };

  return (
    <section id="contact" className="py-24 px-6 md:px-12 max-w-7xl mx-auto border-t border-stone-800">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 text-xs text-stone-400 mb-2 font-mono-tabular">
            <span>Direct Inquiry</span>
            <span aria-hidden="true">·</span>
            <span>24h Response Protocol</span>
            <span aria-hidden="true">·</span>
            <span>Confidential NDA Guaranteed</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
            Ready to Build Your Website?
          </h2>
          <p className="mt-3 text-stone-400 text-sm md:text-base font-body">
            Share your brief, timeline, and architectural targets. Our principal engineering lead will review and respond with an exact sprint blueprint within one business day.
          </p>
        </div>

        {isSubmitted && submissionReceipt ? (
          <div className="p-8 sm:p-10 bg-stone-900 border border-emerald-500/40 rounded-xl text-center space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <h3 className="text-2xl font-display font-semibold text-stone-100">
              Project Brief Received
            </h3>

            <p className="text-sm text-stone-300 max-w-lg mx-auto font-body leading-relaxed">
              Thank you, <span className="font-semibold text-stone-100">{name}</span>. Your architectural discovery inquiry has been routed directly to our senior lead for {archetype}.
            </p>

            <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-lg max-w-md mx-auto text-left font-mono-tabular text-xs space-y-1.5 text-stone-400">
              <div className="flex justify-between">
                <span>Receipt Protocol:</span>
                <span className="text-amber-400 font-bold">{submissionReceipt.id}</span>
              </div>
              <div className="flex justify-between">
                <span>Logged Timestamp:</span>
                <span className="text-stone-200">{submissionReceipt.timestamp}</span>
              </div>
              <div className="flex justify-between">
                <span>Contact Email:</span>
                <span className="text-stone-200">{email}</span>
              </div>
              {initialEstimate && (
                <div className="flex justify-between pt-1 border-t border-stone-800 text-stone-300">
                  <span>Scope Estimate:</span>
                  <span className="text-emerald-400 font-bold">${initialEstimate.total.toLocaleString()} USD</span>
                </div>
              )}
            </div>

            <div className="pt-4">
              <button
                onClick={() => {
                  setIsSubmitted(false);
                  setName('');
                  setEmail('');
                  setNotes('');
                }}
                className="text-xs text-stone-400 hover:text-stone-200 transition-colors underline"
              >
                Submit another project brief
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-8 sm:p-10 bg-stone-900/60 border border-stone-800 rounded-xl shadow-xl space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Name */}
              <div>
                <label className="block text-xs font-mono-tabular text-stone-300 mb-2">
                  Full Name / Principal *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Helena Berg"
                    className={`w-full px-4 py-2.5 bg-stone-950 border rounded-lg text-sm text-stone-100 placeholder:text-stone-600 focus:outline-none transition-colors ${
                      errors.name ? 'border-red-500/70 focus:border-red-500' : 'border-stone-800 focus:border-amber-400'
                    }`}
                  />
                </div>
                {errors.name && (
                  <p className="mt-1.5 text-xs text-red-400 font-mono-tabular">{errors.name}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-mono-tabular text-stone-300 mb-2">
                  Work Email Address *
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className={`w-full px-4 py-2.5 bg-stone-950 border rounded-lg text-sm text-stone-100 placeholder:text-stone-600 focus:outline-none transition-colors ${
                    errors.email ? 'border-red-500/70 focus:border-red-500' : 'border-stone-800 focus:border-amber-400'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1.5 text-xs text-red-400 font-mono-tabular">{errors.email}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Company / Brand */}
              <div>
                <label className="block text-xs font-mono-tabular text-stone-300 mb-2">
                  Company / Organization
                </label>
                <input
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="e.g. Berg Horology SA"
                  className="w-full px-4 py-2.5 bg-stone-950 border border-stone-800 rounded-lg text-sm text-stone-100 placeholder:text-stone-600 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              {/* Archetype */}
              <div>
                <label className="block text-xs font-mono-tabular text-stone-300 mb-2">
                  Target Website Type
                </label>
                <select
                  value={archetype}
                  onChange={(e) => setArchetype(e.target.value)}
                  className="w-full px-4 py-2.5 bg-stone-950 border border-stone-800 rounded-lg text-sm text-stone-100 focus:outline-none focus:border-amber-400 transition-colors cursor-pointer"
                >
                  <option value="Custom E-Commerce">Custom E-Commerce & Merchant Store</option>
                  <option value="Editorial Architecture">Brand Flagship & Portfolio</option>
                  <option value="Full-Stack SaaS">Full-Stack SaaS Web App</option>
                  <option value="Product Launch">High-Impact Landing Page</option>
                  <option value="Artisanal Hospitality">Artisanal Hospitality & Dining</option>
                </select>
              </div>
            </div>

            {/* Notes / Brief */}
            <div>
              <label className="block text-xs font-mono-tabular text-stone-300 mb-2">
                Project Overview & Specific Targets
              </label>
              <textarea
                rows={4}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Briefly describe your brand goals, target audience, preferred visual aesthetic, or any specific integrations..."
                className="w-full px-4 py-3 bg-stone-950 border border-stone-800 rounded-lg text-sm text-stone-100 placeholder:text-stone-600 focus:outline-none focus:border-amber-400 transition-colors font-body"
              />
            </div>

            {/* Submit Action */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap shadow-sm"
              >
                <span>Request Architectural Discovery</span>
                <Send className="w-3.5 h-3.5" />
              </button>

              <span className="text-xs text-stone-500 font-mono-tabular">
                Confidentiality guaranteed · Direct senior engineer review
              </span>
            </div>
          </form>
        )}
      </div>
    </section>
  );
}
