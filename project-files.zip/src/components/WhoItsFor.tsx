import React from 'react';
import { Home, Building2, CheckCircle2, ArrowRight } from 'lucide-react';

export function WhoItsFor() {
  return (
    <section className="bg-[#080f1a]/75 backdrop-blur-md py-24 px-6 sm:px-12 text-[#F5F0E8] border-t border-[#C9A84C]/20 relative z-10" id="audience">
      <div className="max-w-5xl mx-auto">
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-3 font-mono-tabular">
            <span>Tailored Service Solutions</span>
          </div>
          <h2 className="font-serif-logo text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight">
            Residential & Commercial Sectors
          </h2>
          <p className="text-sm sm:text-base text-[#F5F0E8]/75 max-w-xl mt-3 font-sans leading-relaxed">
            Scalable container distribution customized for suburban estates, multi-unit complexes, and commercial enterprises.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Card 1: Households & Residential Estates */}
          <div className="rounded-2xl p-8 sm:p-10 bg-[#080f1a]/92 backdrop-blur-lg border border-[#C9A84C]/40 shadow-2xl relative overflow-hidden flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#C9A84C]/15 border border-[#C9A84C]/35 flex items-center justify-center text-[#C9A84C] mb-6">
                <Home className="w-6 h-6 stroke-[1.8]" />
              </div>

              <h3 className="font-serif-logo text-2xl sm:text-3xl font-bold text-white leading-snug mb-3 group-hover:text-[#e8c96a] transition-colors">
                Households & Estates
              </h3>

              <p className="text-sm text-[#F5F0E8]/80 leading-relaxed mb-6 font-sans">
                Keep your home clean and contribute directly to community landfill diversion. One durable container by your gate is all it takes.
              </p>

              <ul className="space-y-3 border-t border-[#C9A84C]/20 pt-6">
                {[
                  'Ideal for private houses, townhouses & residential complexes',
                  'Dedicated 210L container supplied with weather-sealed lid',
                  'Flexible collection frequency synchronized with your fullness level',
                  'Fosters environmentally responsible household habits'
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-[#F5F0E8]/90">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A84C] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-[#C9A84C]/20">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 text-xs font-bold text-[#C9A84C] hover:text-[#e8c96a] uppercase tracking-wider transition-colors"
              >
                <span>Request Household Drum</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Card 2: Commercial & Corporate Businesses */}
          <div className="rounded-2xl p-8 sm:p-10 bg-gradient-to-br from-[#C9A84C] via-[#deb754] to-[#a68230] text-[#080f1a] shadow-2xl relative overflow-hidden flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#080f1a]/15 border border-[#080f1a]/25 flex items-center justify-center text-[#080f1a] mb-6">
                <Building2 className="w-6 h-6 stroke-[2]" />
              </div>

              <h3 className="font-serif-logo text-2xl sm:text-3xl font-bold text-[#080f1a] leading-snug mb-3">
                Commercial Enterprises
              </h3>

              <p className="text-sm text-[#080f1a]/90 leading-relaxed mb-6 font-medium">
                Demonstrate tangible corporate sustainability with zero operational overhead. We deliver and service high-volume recycling infrastructure.
              </p>

              <ul className="space-y-3 border-t border-[#080f1a]/20 pt-6">
                {[
                  'Restaurants, corporate headquarters, retail centers & schools',
                  'Multiple container deployments tailored to facility volume',
                  'Scheduled weekly or bi-weekly route collection rosters',
                  'Verifiable ESG waste diversion records for corporate compliance'
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-[#080f1a] font-bold">
                    <CheckCircle2 className="w-4 h-4 text-[#080f1a] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-[#080f1a]/20">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 text-xs font-bold text-[#080f1a] hover:underline uppercase tracking-wider transition-colors"
              >
                <span>Request Commercial Containers</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
