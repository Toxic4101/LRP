import React from 'react';
import { Award, Shield, CheckCircle2, Sparkles, UserCheck } from 'lucide-react';

interface DirectorMember {
  name: string;
  role: string;
  badge?: string;
  initials: string;
  focus: string;
  isFounder?: boolean;
}

const EXECUTIVE_CHIEFS: DirectorMember[] = [
  {
    name: 'Armand',
    role: 'Chief Executive Officer (CEO) (Founder)',
    badge: 'Founder & CEO',
    initials: 'AR',
    focus: 'Founding visionary and chief executive driving nationwide landfill diversion, municipal partner alliances, route expansion, and sustainable circular infrastructure.',
    isFounder: true
  },
  {
    name: 'Braam',
    role: 'Managing Director (MD)',
    badge: 'Managing Director',
    initials: 'BR',
    focus: 'Operational leadership, route distribution strategies, community rollouts, and executive stakeholder management.',
  }
];

const EXECUTIVE_DIRECTORS: DirectorMember[] = [
  {
    name: 'Andre',
    role: 'Chief Operating Officer (COO)',
    badge: 'Operations',
    initials: 'AN',
    focus: 'Logistics infrastructure, processing facility operations, collection fleet reliability, and material recovery.'
  },
  {
    name: 'Amia',
    role: 'Chief Financial Officer (CFO)',
    badge: 'Finance',
    initials: 'AM',
    focus: 'Financial strategy, capital allocation, ESG compliance accountability, and sustainable fiscal governance.'
  },
  {
    name: 'Danielle',
    role: 'Executive Director of Corporate Relations',
    badge: 'Corporate Relations',
    initials: 'DA',
    focus: 'Corporate relations, community stakeholder advocacy, brand stewardship, and enterprise commercial partnerships.'
  }
];

export function LeadershipSection() {
  return (
    <section className="bg-[#080f1a]/75 backdrop-blur-md py-24 px-6 sm:px-12 text-[#F5F0E8] border-t border-[#C9A84C]/20 relative z-10" id="leadership">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-4 font-mono-tabular">
            <span>Executive Board & Stewardship</span>
          </div>

          <h2 className="font-serif-logo text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight mb-4">
            People That Build The Company Up To Make This World A Better Place
          </h2>

          <p className="text-sm sm:text-base text-[#F5F0E8]/80 leading-relaxed font-sans">
            Guided by executive stewardship dedicated to eradicating municipal landfill waste, empowering local communities, and delivering high-grade circular infrastructure.
          </p>
        </div>

        {/* Tier 1: Executive Principals (Founder & CEO + Managing Director) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {EXECUTIVE_CHIEFS.map((member, idx) => (
            <div
              key={idx}
              className={`rounded-2xl p-7 transition-all duration-300 flex flex-col justify-between group ${
                member.isFounder
                  ? 'bg-[#080f1a]/95 backdrop-blur-lg border-2 border-[#C9A84C]/70 shadow-2xl relative overflow-hidden'
                  : 'bg-[#080f1a]/90 backdrop-blur-lg hover:bg-[#080f1a] border border-[#C9A84C]/35 hover:border-[#C9A84C]/65 shadow-xl'
              }`}
            >
              {member.badge && (
                <div className="absolute top-0 right-0 bg-[#C9A84C] text-[#080f1a] text-[10px] font-mono-tabular font-extrabold uppercase px-3 py-1 rounded-bl-xl tracking-wider shadow-sm">
                  {member.badge}
                </div>
              )}

              <div>
                <div className="flex items-start gap-4 mb-5">
                  <div
                    className={`w-14 h-14 rounded-2xl shrink-0 flex items-center justify-center font-serif-logo text-lg font-bold transition-all shadow-md ${
                      member.isFounder
                        ? 'bg-[#C9A84C] text-[#080f1a] ring-2 ring-[#C9A84C]/40'
                        : 'bg-[#1A2B4A] text-[#C9A84C] border border-[#C9A84C]/40 group-hover:bg-[#1e3057]'
                    }`}
                  >
                    {member.initials}
                  </div>

                  <div>
                    <h3 className="font-serif-logo text-2xl font-bold text-white group-hover:text-[#e8c96a] transition-colors leading-tight">
                      {member.name}
                    </h3>
                    <div className="text-xs font-mono-tabular font-bold text-[#C9A84C] uppercase tracking-wider mt-1 leading-snug">
                      {member.role}
                    </div>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-[#F5F0E8]/80 leading-relaxed font-sans">
                  {member.focus}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] font-mono-tabular text-[#F5F0E8]/50">
                <span>{member.isFounder ? 'Founding Executive' : 'Executive Principal'}</span>
                <span className="text-[#C9A84C] flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Tier 2: Operational Directorship (COO, CFO, Exec Director) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {EXECUTIVE_DIRECTORS.map((member, idx) => (
            <div
              key={idx}
              className="rounded-2xl p-6 sm:p-7 bg-[#080f1a]/90 backdrop-blur-lg hover:bg-[#080f1a] border border-[#C9A84C]/30 hover:border-[#C9A84C]/60 shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start gap-4 mb-5">
                  <div className="w-13 h-13 rounded-2xl shrink-0 flex items-center justify-center font-serif-logo text-base font-bold bg-[#1A2B4A] text-[#C9A84C] border border-[#C9A84C]/30 group-hover:border-[#C9A84C]/60 group-hover:bg-[#1e3057] transition-all shadow-md">
                    {member.initials}
                  </div>

                  <div>
                    <h3 className="font-serif-logo text-xl font-bold text-white group-hover:text-[#e8c96a] transition-colors leading-tight">
                      {member.name}
                    </h3>
                    <div className="text-[11px] font-mono-tabular font-semibold text-[#C9A84C] uppercase tracking-wider mt-1 leading-snug">
                      {member.role}
                    </div>
                  </div>
                </div>

                <p className="text-xs text-[#F5F0E8]/75 leading-relaxed font-sans">
                  {member.focus}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[11px] font-mono-tabular text-[#F5F0E8]/50">
                <span>Executive Board</span>
                <span className="text-[#C9A84C] flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Corporate Commitment Note */}
        <div className="mt-12 p-6 rounded-2xl bg-[#080f1a]/85 backdrop-blur-md border border-[#C9A84C]/30 text-center max-w-3xl mx-auto shadow-lg">
          <p className="text-xs sm:text-sm text-[#F5F0E8]/85 leading-relaxed font-sans">
            Our leadership team remains hands-on in the field, ensuring every household drum delivered and commercial route operated upholds our founding covenant of <strong className="text-[#C9A84C]">integrity, reliability, and circular sustainability</strong>.
          </p>
        </div>
      </div>
    </section>
  );
}
