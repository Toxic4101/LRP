import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, Package, Layers, Sparkles } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

export function DrumIllustration() {
  const [fillCount, setFillCount] = useState<number>(14);
  const [activeHighlight, setActiveHighlight] = useState<string>('all');

  const materialTags = [
    { label: 'Aluminium Cans', code: 'ALU' },
    { label: 'PET & HDPE Bottles', code: 'PLAST' },
    { label: 'Corrugated Cardboard', code: 'KRAFT' },
    { label: 'Glass Jars & Bottles', code: 'GLS' },
  ];

  return (
    <div className="w-full max-w-md mx-auto select-none flex flex-col items-center">
      {/* Container Header Badge */}
      <div className="flex items-center gap-2 mb-4 bg-[#080f1a]/85 border border-[#C9A84C]/35 rounded-full px-4 py-1.5 text-xs font-mono-tabular">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-[#C9A84C] font-bold">LEGACY 210L RECYCLING DRUM</span>
        <span className="text-[#F5F0E8]/40">·</span>
        <span className="text-[#F5F0E8]/80">Single-Stream</span>
      </div>

      {/* Main Vector Architectural Drum Card */}
      <div className="relative w-full rounded-2xl bg-gradient-to-b from-[#0f1c30] via-[#0b1626] to-[#080f1a] border-2 border-[#C9A84C]/40 p-6 sm:p-8 shadow-2xl shadow-black/70 flex flex-col items-center overflow-hidden group">
        {/* Subtle Ambient Radial Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-[#C9A84C]/5 rounded-full blur-2xl pointer-events-none" />

        {/* 3D Vector Drum Illustration (Precise Official Legacy Unit) */}
        <div className="relative w-[240px] h-[310px] flex justify-center items-end my-2">
          {/* Ground Contact Shadow */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-48 h-6 bg-black/60 rounded-full blur-md" />

          {/* Weatherproof Secure Lid */}
          <div className="absolute bottom-[240px] left-1/2 -translate-x-1/2 w-[210px] h-[22px] bg-gradient-to-r from-[#203960] via-[#2c4e85] to-[#1a2e4e] rounded-t-lg rounded-b-sm border-2 border-[#4572b8] shadow-lg flex items-center justify-center z-20">
            {/* Lid Handle */}
            <div className="w-14 h-2 bg-[#0d1829] rounded-sm border border-[#C9A84C]/60" />
            {/* Clamp Latches */}
            <div className="absolute left-3 top-1 w-2.5 h-3.5 bg-[#C9A84C] rounded-xs shadow-xs" />
            <div className="absolute right-3 top-1 w-2.5 h-3.5 bg-[#C9A84C] rounded-xs shadow-xs" />
          </div>

          {/* Heavy-Duty Drum Body */}
          <div className="relative w-[190px] h-[245px] bg-gradient-to-r from-[#0c182c] via-[#162a4a] to-[#0a1526] rounded-b-2xl border-[3px] border-[#2e4f8a] shadow-2xl overflow-hidden flex flex-col items-center justify-center">
            {/* Metallic Sheen Stripe */}
            <div className="absolute inset-y-0 left-5 w-8 bg-gradient-to-r from-transparent via-white/10 to-transparent pointer-events-none" />

            {/* Embossed Gold Structural Ribs */}
            <div className="absolute top-8 left-0 right-0 h-1.5 bg-[#C9A84C]/50 shadow-inner" />
            <div className="absolute bottom-10 left-0 right-0 h-1.5 bg-[#C9A84C]/50 shadow-inner" />

            {/* Center Official Brand Emblem Plate */}
            <div className="relative z-10 bg-[#080f1a]/95 border-2 border-[#C9A84C]/70 rounded-xl p-3 text-center shadow-xl w-[148px] backdrop-blur-xs">
              {/* Mini Official Arch Gate & Recycling Vector */}
              <div className="flex justify-center mb-1">
                <svg viewBox="0 0 100 70" className="w-10 h-7 text-[#C9A84C]" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M 18 65 L 18 36 C 18 16 32 6 50 6 C 68 6 82 16 82 36 L 82 65" stroke="#C9A84C" strokeWidth="3" />
                  <line x1="12" y1="65" x2="88" y2="65" stroke="#C9A84C" strokeWidth="3.5" />
                  <circle cx="50" cy="36" r="14" stroke="#C9A84C" strokeWidth="1.8" strokeDasharray="6 3" />
                  <path d="M 44 28 L 54 28 L 50 22 Z" fill="#C9A84C" />
                  <path d="M 58 38 L 58 48 L 64 44 Z" fill="#C9A84C" />
                  <path d="M 42 44 L 42 34 L 36 38 Z" fill="#C9A84C" />
                </svg>
              </div>

              <div className="font-serif-logo text-base text-white font-bold tracking-[0.06em] leading-none">
                LEGACY
              </div>
              <div className="h-[1px] bg-[#C9A84C] my-1 opacity-80 w-full" />
              <div className="text-[7px] font-extrabold tracking-[0.16em] text-[#C9A84C] uppercase leading-tight">
                RESOURCE PARTNERS
              </div>
              <div className="text-[6.5px] font-bold tracking-[0.22em] text-[#F5F0E8]/80 uppercase leading-tight">
                RECYCLING
              </div>
            </div>

            {/* Container Specs Label at Bottom */}
            <div className="absolute bottom-2 font-mono-tabular text-[9px] text-[#C9A84C]/90 font-semibold uppercase tracking-wider">
              210 Litres · UV-HDPE
            </div>
          </div>
        </div>

        {/* Accepted Material Quick Tags Below Drum */}
        <div className="w-full mt-4 pt-4 border-t border-[#C9A84C]/20 grid grid-cols-2 gap-2 text-xs">
          {materialTags.map((tag, idx) => (
            <div
              key={idx}
              className="p-2 rounded-lg bg-white/[0.03] border border-[#C9A84C]/20 flex items-center justify-between"
            >
              <span className="text-[#F5F0E8]/80 text-[11px] truncate font-medium">{tag.label}</span>
              <span className="text-[9px] font-mono-tabular text-[#C9A84C] font-bold bg-[#C9A84C]/10 px-1.5 py-0.5 rounded shrink-0">
                {tag.code}
              </span>
            </div>
          ))}
        </div>

        {/* Bottom Feature Assurance */}
        <div className="mt-4 flex items-center justify-between w-full text-[11px] font-mono-tabular text-[#F5F0E8]/60 pt-2 border-t border-white/5">
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" /> Zero Container Fee
          </span>
          <span className="text-[#C9A84C] font-semibold">
            Direct Gate Drop-Off
          </span>
        </div>
      </div>
    </div>
  );
}
