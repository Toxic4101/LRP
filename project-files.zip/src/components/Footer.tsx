import React from 'react';

interface FooterProps {
  onBackToTop: () => void;
  onRequestQuote: () => void;
}

export function Footer({ onBackToTop, onRequestQuote }: FooterProps) {
  return (
    <footer className="border-t border-stone-800 bg-stone-950 py-16 px-6 md:px-12">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
        <div className="space-y-4 max-w-sm">
          <a href="#" className="text-lg font-display font-bold tracking-tight text-stone-100 hover:text-amber-400 transition-colors">
            Vanguard Studio
          </a>
          <p className="text-xs text-stone-400 font-body leading-relaxed">
            Creative digital atelier and web architecture practice. We engineer high-performance web flagships, e-commerce stores, and software platforms.
          </p>
          <div className="text-xs text-stone-500 font-mono-tabular">
            Geneva · London · Helsinki
          </div>
        </div>

        <div className="flex flex-wrap gap-8 text-xs font-medium text-stone-400">
          <a href="#works" className="hover:text-stone-100 transition-colors">
            Selected Works
          </a>
          <a href="#capabilities" className="hover:text-stone-100 transition-colors">
            Capabilities
          </a>
          <a href="#prototypes" className="hover:text-stone-100 transition-colors">
            Live Showcase
          </a>
          <a href="#estimator" className="hover:text-stone-100 transition-colors">
            Cost Estimator
          </a>
          <a href="#contact" className="hover:text-stone-100 transition-colors">
            Contact
          </a>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 text-xs font-mono-tabular text-stone-500">
          <button
            onClick={onBackToTop}
            className="text-stone-400 hover:text-stone-200 transition-colors underline"
          >
            Back to Top ↑
          </button>
          <span>© 2026 Vanguard Studio. All rights reserved.</span>
        </div>
      </div>
    </footer>
  );
}
