import React, { useState, useMemo } from 'react';
import { Calculator, Clock, Check, ArrowRight, ShieldCheck } from 'lucide-react';

interface EstimatorProps {
  onApplyEstimate: (estimateSummary: {
    archetype: string;
    addons: string[];
    timeline: string;
    total: number;
    weeks: number;
  }) => void;
}

interface ArchetypeOption {
  id: string;
  name: string;
  basePrice: number;
  baseWeeks: number;
  description: string;
}

const ARCHETYPES: ArchetypeOption[] = [
  {
    id: 'portfolio',
    name: 'Brand Flagship & Editorial Portfolio',
    basePrice: 4800,
    baseWeeks: 3,
    description: 'Bespoke typography, monograph layouts, responsive showcase, and lightning performance.'
  },
  {
    id: 'ecommerce',
    name: 'Custom E-Commerce & Merchant Store',
    basePrice: 8500,
    baseWeeks: 4,
    description: 'Headless storefront, inventory sync, product variant customizers, and Stripe checkout.'
  },
  {
    id: 'saas',
    name: 'Full-Stack SaaS Web Application',
    basePrice: 12500,
    baseWeeks: 6,
    description: 'Auth & roles, relational database, user dashboards, billing portal, and API integrations.'
  },
  {
    id: 'landing',
    name: 'High-Impact Product Launch & Lead Engine',
    basePrice: 3800,
    baseWeeks: 2,
    description: 'Single-page conversion funnel, interactive demo elements, and validated lead pipelines.'
  }
];

const ADDONS = [
  { id: 'cms', name: 'Headless CMS Integration', price: 1200, time: 0.5 },
  { id: 'intl', name: 'Multi-Currency & International Tax Engine', price: 1800, time: 1.0 },
  { id: 'webgl', name: 'Interactive 3D / WebGL Canvas Viewport', price: 2400, time: 1.5 },
  { id: 'crm', name: 'Automated CRM & Webhook Pipeline', price: 900, time: 0.5 },
  { id: 'seo', name: 'Full SEO Architecture & Schema JSON-LD', price: 850, time: 0.5 }
];

export function Estimator({ onApplyEstimate }: EstimatorProps) {
  const [selectedArchetype, setSelectedArchetype] = useState<string>('ecommerce');
  const [selectedAddons, setSelectedAddons] = useState<string[]>(['cms', 'seo']);
  const [deliveryPace, setDeliveryPace] = useState<'standard' | 'expedited'>('standard');

  const currentArchetype = useMemo(() => {
    return ARCHETYPES.find(a => a.id === selectedArchetype) || ARCHETYPES[0];
  }, [selectedArchetype]);

  const toggleAddon = (id: string) => {
    setSelectedAddons(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const calculatedTotals = useMemo(() => {
    const addonPrice = selectedAddons.reduce((sum, id) => {
      const addon = ADDONS.find(a => a.id === id);
      return sum + (addon ? addon.price : 0);
    }, 0);

    const addonTime = selectedAddons.reduce((sum, id) => {
      const addon = ADDONS.find(a => a.id === id);
      return sum + (addon ? addon.time : 0);
    }, 0);

    let rawPrice = currentArchetype.basePrice + addonPrice;
    let rawWeeks = currentArchetype.baseWeeks + addonTime;

    if (deliveryPace === 'expedited') {
      rawPrice = Math.round(rawPrice * 1.25);
      rawWeeks = Math.max(1.5, Math.round(rawWeeks * 0.65 * 10) / 10);
    }

    return {
      price: rawPrice,
      weeks: Math.round(rawWeeks * 10) / 10
    };
  }, [currentArchetype, selectedAddons, deliveryPace]);

  const handleApply = () => {
    onApplyEstimate({
      archetype: currentArchetype.name,
      addons: selectedAddons.map(id => ADDONS.find(a => a.id === id)?.name || id),
      timeline: deliveryPace === 'expedited' ? 'Expedited Sprint' : 'Standard Sprint',
      total: calculatedTotals.price,
      weeks: calculatedTotals.weeks
    });
  };

  return (
    <section id="estimator" className="py-24 px-6 md:px-12 max-w-7xl mx-auto border-t border-stone-800">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-400 mb-2 font-mono-tabular">
            <span>Project Calculator</span>
            <span aria-hidden="true">·</span>
            <span>Transparent Investment</span>
            <span aria-hidden="true">·</span>
            <span>Fixed-Scope Sprints</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
            Interactive Scope & Investment Estimator
          </h2>
          <p className="mt-3 text-stone-400 text-sm md:text-base max-w-2xl font-body">
            Configure your intended website architecture below to immediately calculate estimated delivery milestones and transparent pricing.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-stone-400 font-mono-tabular bg-stone-900 border border-stone-800 px-3.5 py-2 rounded-lg shrink-0">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Guaranteed fixed-bid milestones</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Config Controls (8 Cols) */}
        <div className="lg:col-span-7 space-y-8">
          {/* Step 1: Archetype selection */}
          <div>
            <div className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-3">
              Step 1: Choose Website Architecture Archetype
            </div>
            <div className="space-y-3">
              {ARCHETYPES.map(arch => (
                <button
                  key={arch.id}
                  onClick={() => setSelectedArchetype(arch.id)}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    selectedArchetype === arch.id
                      ? 'bg-stone-900 border-amber-500/60 ring-1 ring-amber-500/30'
                      : 'bg-stone-900/40 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-baseline justify-between">
                    <span className="font-semibold text-stone-100 text-sm sm:text-base">
                      {arch.name}
                    </span>
                    <span className="font-mono-tabular text-xs font-bold text-amber-400">
                      From ${arch.basePrice.toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-1.5 text-xs text-stone-400 leading-relaxed font-body">
                    {arch.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Add-on Capabilities */}
          <div>
            <div className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-3">
              Step 2: Specialized Capabilities & Integrations
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ADDONS.map(addon => {
                const isSelected = selectedAddons.includes(addon.id);
                return (
                  <button
                    key={addon.id}
                    onClick={() => toggleAddon(addon.id)}
                    className={`p-3.5 rounded-lg border text-left transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-stone-900 border-amber-500/40'
                        : 'bg-stone-900/30 border-stone-800 hover:border-stone-700'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center shrink-0 border ${
                      isSelected ? 'bg-amber-400 border-amber-400 text-stone-950' : 'border-stone-700 bg-stone-950'
                    }`}>
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div>
                      <div className="text-xs font-medium text-stone-200 leading-tight">
                        {addon.name}
                      </div>
                      <div className="text-[11px] font-mono-tabular text-stone-400 mt-1">
                        +${addon.price.toLocaleString()}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 3: Delivery Pace */}
          <div>
            <div className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-3">
              Step 3: Delivery Timeline Schedule
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setDeliveryPace('standard')}
                className={`p-4 rounded-lg border text-left transition-all ${
                  deliveryPace === 'standard'
                    ? 'bg-stone-900 border-amber-500/40 text-stone-100'
                    : 'bg-stone-900/30 border-stone-800 text-stone-400 hover:border-stone-700'
                }`}
              >
                <div className="text-xs font-semibold text-stone-200">Standard Production</div>
                <div className="text-[11px] text-stone-400 mt-0.5">Carefully paced review cycles</div>
              </button>
              <button
                onClick={() => setDeliveryPace('expedited')}
                className={`p-4 rounded-lg border text-left transition-all ${
                  deliveryPace === 'expedited'
                    ? 'bg-stone-900 border-amber-500/40 text-stone-100'
                    : 'bg-stone-900/30 border-stone-800 text-stone-400 hover:border-stone-700'
                }`}
              >
                <div className="text-xs font-semibold text-amber-400">Expedited Sprint (+25%)</div>
                <div className="text-[11px] text-stone-400 mt-0.5">Priority dedicated engineering team</div>
              </button>
            </div>
          </div>
        </div>

        {/* Right Summary Card (5 Cols Sticky) */}
        <div className="lg:col-span-5 sticky top-24">
          <div className="p-6 md:p-8 bg-stone-900 border border-stone-800 rounded-xl shadow-xl space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-stone-800">
              <div className="font-display font-semibold text-stone-100">Scope Summary</div>
              <span className="text-xs font-mono-tabular text-amber-400">Ready to Lock</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between items-start text-stone-300">
                <span>Architecture Archetype:</span>
                <span className="font-semibold text-stone-100 text-right max-w-[200px] truncate">
                  {currentArchetype.name}
                </span>
              </div>
              <div className="flex justify-between items-center text-stone-300">
                <span>Timeline Schedule:</span>
                <span className="font-mono-tabular text-stone-100">
                  {calculatedTotals.weeks} Weeks ({deliveryPace === 'expedited' ? 'Expedited' : 'Standard'})
                </span>
              </div>
              <div className="flex justify-between items-start text-stone-300">
                <span>Active Modules:</span>
                <span className="font-mono-tabular text-stone-100 text-right">
                  {selectedAddons.length} Selected
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-stone-800">
              <div className="text-xs text-stone-400">Estimated Total Investment</div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-3xl md:text-4xl font-display font-bold text-amber-400 font-mono-tabular">
                  ${calculatedTotals.price.toLocaleString()}
                </span>
                <span className="text-xs text-stone-400 font-mono-tabular">USD (Fixed-Bid)</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={handleApply}
                className="w-full py-3.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Request Scope with This Estimate</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <p className="text-[11px] text-stone-500 text-center font-mono-tabular">
                Includes 30-day post-launch warranty & CI/CD deployment
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
