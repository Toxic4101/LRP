import React from 'react';
import { DrumIllustration } from './DrumIllustration';
import { ArrowRight, ShieldCheck, Check, Sparkles } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center pt-28 pb-20 px-6 sm:px-12 overflow-hidden bg-transparent z-10">
      {/* Background Subtle Ambient Glow */}
      <div 
        className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_60%_40%,rgba(30,48,87,0.35)_0%,transparent_70%)]" 
      />

      {/* Subtle Background Watermark Word */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 font-serif-logo text-[clamp(100px,20vw,260px)] text-[#C9A84C]/[0.035] whitespace-nowrap tracking-widest select-none pointer-events-none">
        LEGACY
      </div>

      <div className="relative z-10 max-w-6xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        {/* Left Column: Proposition, Copy & Action (7 cols) */}
        <div className="lg:col-span-7 flex flex-col items-start text-left p-6 sm:p-8 rounded-3xl bg-[#080f1a]/60 backdrop-blur-md border border-[#C9A84C]/25 shadow-2xl">
          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2.5 bg-[#C9A84C]/15 border border-[#C9A84C]/45 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase text-[#C9A84C] mb-6 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-[#c6ff00] animate-pulse" />
            <span className="font-mono-tabular">Legacy Resource Partners · Environmental Initiative</span>
          </div>

          {/* Main Headline */}
          <h1 className="font-serif-logo text-4xl sm:text-5xl md:text-6xl lg:text-[68px] text-white leading-[1.08] tracking-tight mb-2 drop-shadow-md">
            We Provide The Drum.
            <span className="text-[#C9A84C] block mt-1">You Fill It.</span>
          </h1>

          {/* Subtitle / Value Proposition */}
          <p className="text-base sm:text-lg text-[#F5F0E8]/85 leading-relaxed max-w-xl my-6 font-sans">
            Enroll today to receive a <strong className="text-white font-semibold">complimentary 210-litre recycling drum</strong> for your private residence, gated community, or business. Deposit your dry recyclables—our collection team empties, maintains, and responsibly processes everything. <strong className="text-[#e8c96a] font-semibold">Together, we build a cleaner South Africa.</strong>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center gap-4 mb-10 w-full sm:w-auto">
            <a
              href="#contact"
              className="bg-[#C9A84C] hover:bg-[#e8c96a] text-[#080f1a] font-bold text-sm sm:text-base py-3.5 px-8 rounded-xl transition-all transform hover:-translate-y-0.5 shadow-xl shadow-[#C9A84C]/25 flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <span>Claim Your Free Drum</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </a>

            <a
              href="#how"
              className="bg-[#080f1a]/80 hover:bg-[#080f1a] text-[#F5F0E8] font-semibold text-sm sm:text-base py-3.5 px-6 rounded-xl border border-[#C9A84C]/35 hover:border-[#C9A84C]/70 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>How It Works</span>
              <ArrowRight className="w-4 h-4 text-[#C9A84C]" />
            </a>
          </div>

          {/* Stat Row */}
          <div className="w-full pt-8 border-t border-[#C9A84C]/25 grid grid-cols-3 gap-6 sm:gap-10">
            <div>
              <div className="font-serif-logo text-3xl sm:text-4xl text-[#C9A84C] leading-none font-bold">
                100%
              </div>
              <div className="text-[11px] sm:text-xs text-[#F5F0E8]/70 uppercase tracking-wider mt-1.5 font-mono-tabular">
                Free Enrollment
              </div>
            </div>

            <div>
              <div className="font-serif-logo text-3xl sm:text-4xl text-[#C9A84C] leading-none font-bold">
                R0.00
              </div>
              <div className="text-[11px] sm:text-xs text-[#F5F0E8]/70 uppercase tracking-wider mt-1.5 font-mono-tabular">
                Zero Cost Ever
              </div>
            </div>

            <div>
              <div className="font-serif-logo text-3xl sm:text-4xl text-[#C9A84C] leading-none font-bold">
                100%
              </div>
              <div className="text-[11px] sm:text-xs text-[#F5F0E8]/70 uppercase tracking-wider mt-1.5 font-mono-tabular">
                Landfill Diversion
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Visual Drum (5 cols) */}
        <div className="lg:col-span-5 flex justify-center items-center w-full">
          <DrumIllustration />
        </div>
      </div>
    </section>
  );
}
