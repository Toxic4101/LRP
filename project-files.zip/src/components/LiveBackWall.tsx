import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Dna, Sliders, Eye, Zap } from 'lucide-react';

interface LiveBackWallProps {
  className?: string;
}

interface AmbientParticle {
  x: number;
  y: number;
  z: number;
  radius: number;
  vx: number;
  vy: number;
  alpha: number;
}

export function LiveBackWall({ className = '' }: LiveBackWallProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [palette, setPalette] = useState<'lime' | 'gold' | 'cyan'>('lime');
  const [intensity, setIntensity] = useState<'subtle' | 'balanced' | 'vivid'>('vivid');
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Mouse coordinates with smooth damping
    const mouse = {
      x: width / 2,
      y: height / 2,
      targetX: width / 2,
      targetY: height / 2,
      tiltX: 0,
      tiltY: 0
    };

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initParticles();
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);

    // Ambient floating particles
    let particles: AmbientParticle[] = [];
    const numParticles = 35;

    const initParticles = () => {
      particles = [];
      for (let i = 0; i < numParticles; i++) {
        particles.push({
          x: (Math.random() - 0.5) * width * 1.5,
          y: (Math.random() - 0.5) * height * 1.5,
          z: Math.random() * 800 - 400,
          radius: 1 + Math.random() * 2.2,
          vx: (Math.random() - 0.5) * 0.25,
          vy: (Math.random() - 0.5) * 0.25,
          alpha: 0.2 + Math.random() * 0.4
        });
      }
    };

    initParticles();

    let rotationAngle = 0;
    let waveTime = 0;

    // Render 3D DNA Double Helix Loop
    const render = () => {
      if (!isPaused) {
        rotationAngle += 0.018;
        waveTime += 0.014;

        // Smooth mouse damping
        mouse.x += (mouse.targetX - mouse.x) * 0.04;
        mouse.y += (mouse.targetY - mouse.y) * 0.04;

        // Map mouse to subtle 3D camera tilt
        mouse.tiltX = ((mouse.x - width / 2) / width) * 0.4;
        mouse.tiltY = ((mouse.y - height / 2) / height) * 0.3;

        // Drift ambient particles
        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          p.x += p.vx;
          p.y += p.vy;
          if (p.x > width * 0.75) p.x = -width * 0.75;
          if (p.x < -width * 0.75) p.x = width * 0.75;
          if (p.y > height * 0.75) p.y = -height * 0.75;
          if (p.y < -height * 0.75) p.y = height * 0.75;
        }
      }

      ctx.clearRect(0, 0, width, height);

      // Color Theme Config
      let strand1Color = '#c6ff00'; // Bio-Lime primary
      let strand2Color = '#00e5ff'; // Cyan complementary
      let rungsColor = 'rgba(198, 255, 0, ';
      let glowColor = 'rgba(198, 255, 0, 0.6)';

      if (palette === 'gold') {
        strand1Color = '#C9A84C'; // Legacy Gold
        strand2Color = '#f3d887'; // Warm Bright Gold
        rungsColor = 'rgba(201, 168, 76, ';
        glowColor = 'rgba(201, 168, 76, 0.6)';
      } else if (palette === 'cyan') {
        strand1Color = '#00e5ff';
        strand2Color = '#00ffa3';
        rungsColor = 'rgba(0, 229, 255, ';
        glowColor = 'rgba(0, 229, 255, 0.6)';
      }

      const alphaMultiplier = intensity === 'vivid' ? 1.0 : intensity === 'balanced' ? 0.75 : 0.5;

      // Camera Perspective Projection Settings
      const focalLength = 680;
      const centerX = width * 0.54;
      const centerY = height * 0.5;

      // DNA Helix Geometry Settings
      // Diagonal tilt angle across the viewport
      const helixTiltAngle = -0.38 + mouse.tiltY * 0.25;
      const helixRadius = Math.min(width, height) * 0.24;
      const numRungs = 64; // High density of base pairs along the length
      const totalTurns = 4.0; // Full helical spiral twists
      const helixLength = Math.max(height * 1.5, 1200);

      interface RenderItem {
        type: 'backbone_segment' | 'rung' | 'particle';
        z: number;
        draw: () => void;
      }

      const renderQueue: RenderItem[] = [];

      // 1. Queue Ambient Floating Particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const scale = focalLength / (focalLength + p.z + 500);
        const projX = centerX + p.x * scale;
        const projY = centerY + p.y * scale;

        renderQueue.push({
          type: 'particle',
          z: p.z,
          draw: () => {
            ctx.beginPath();
            ctx.arc(projX, projY, Math.max(0.6, p.radius * scale), 0, Math.PI * 2);
            ctx.fillStyle = rungsColor + (p.alpha * alphaMultiplier * 0.8) + ')';
            ctx.fill();
          }
        });
      }

      // 2. Generate DNA Double Helix 3D Coordinates
      const projectedStrand1: { x: number; y: number; z: number; scale: number }[] = [];
      const projectedStrand2: { x: number; y: number; z: number; scale: number }[] = [];

      for (let i = 0; i < numRungs; i++) {
        const progress = (i / (numRungs - 1)) - 0.5;
        const currentY = progress * helixLength;

        // Angle around the helical cylinder
        const theta = progress * totalTurns * Math.PI * 2 + rotationAngle;

        // Minor undulation wave
        const waveX = Math.sin(waveTime + progress * 3.5) * 20;
        const waveZ = Math.cos(waveTime + progress * 3.5) * 16;

        // 3D coordinates for Strand 1
        const rawX1 = Math.cos(theta) * helixRadius + waveX;
        const rawY1 = currentY;
        const rawZ1 = Math.sin(theta) * helixRadius + waveZ;

        // 3D coordinates for Strand 2 (Offset by 180 degrees)
        const rawX2 = Math.cos(theta + Math.PI) * helixRadius + waveX;
        const rawY2 = currentY;
        const rawZ2 = Math.sin(theta + Math.PI) * helixRadius + waveZ;

        // Apply 3D Rotation / Diagonal Tilt
        const cosTilt = Math.cos(helixTiltAngle);
        const sinTilt = Math.sin(helixTiltAngle);
        const cosYaw = Math.cos(mouse.tiltX);
        const sinYaw = Math.sin(mouse.tiltX);

        // Strand 1
        const yx1 = rawX1 * cosYaw - rawZ1 * sinYaw;
        const yz1 = rawX1 * sinYaw + rawZ1 * cosYaw;
        const tx1 = yx1;
        const ty1 = rawY1 * cosTilt - yz1 * sinTilt;
        const tz1 = rawY1 * sinTilt + yz1 * cosTilt;

        // Strand 2
        const yx2 = rawX2 * cosYaw - rawZ2 * sinYaw;
        const yz2 = rawX2 * sinYaw + rawZ2 * cosYaw;
        const tx2 = yx2;
        const ty2 = rawY2 * cosTilt - yz2 * sinTilt;
        const tz2 = rawY2 * sinTilt + yz2 * cosTilt;

        // Perspective projection
        const scale1 = focalLength / (focalLength + tz1 + 450);
        const projX1 = centerX + tx1 * scale1;
        const projY1 = centerY + ty1 * scale1;

        const scale2 = focalLength / (focalLength + tz2 + 450);
        const projX2 = centerX + tx2 * scale2;
        const projY2 = centerY + ty2 * scale2;

        projectedStrand1.push({ x: projX1, y: projY1, z: tz1, scale: scale1 });
        projectedStrand2.push({ x: projX2, y: projY2, z: tz2, scale: scale2 });

        // Base Pair Rung Connecting Strand 1 and Strand 2
        const midZ = (tz1 + tz2) / 2;
        const baseType = i % 4;

        renderQueue.push({
          type: 'rung',
          z: midZ,
          draw: () => {
            const depthFactor = (midZ + helixRadius) / (helixRadius * 2);
            const clampedDepth = Math.max(0.2, Math.min(1, depthFactor));
            const rungAlpha = (0.28 + clampedDepth * 0.72) * alphaMultiplier;

            // Draw Base Pair Rung
            ctx.beginPath();
            ctx.moveTo(projX1, projY1);
            ctx.lineTo(projX2, projY2);
            ctx.strokeStyle = rungsColor + rungAlpha + ')';
            ctx.lineWidth = Math.max(1.2, (1.5 + clampedDepth * 2.8));
            ctx.stroke();

            // Central Hydrogen Bond Junction / Nucleotide Center Node
            const midX = (projX1 + projX2) / 2;
            const midY = (projY1 + projY2) / 2;
            const bondRadius = Math.max(1.8, 3.0 * ((scale1 + scale2) / 2));

            ctx.beginPath();
            ctx.arc(midX, midY, bondRadius, 0, Math.PI * 2);
            ctx.fillStyle = baseType % 2 === 0 ? strand1Color : strand2Color;
            ctx.shadowColor = glowColor;
            ctx.shadowBlur = intensity === 'vivid' ? 8 : 4;
            ctx.fill();
            ctx.shadowBlur = 0;
          }
        });
      }

      // 3. Queue Backbone Sugar-Phosphate Strands
      for (let i = 0; i < numRungs - 1; i++) {
        const p1A = projectedStrand1[i];
        const p1B = projectedStrand1[i + 1];

        renderQueue.push({
          type: 'backbone_segment',
          z: (p1A.z + p1B.z) / 2,
          draw: () => {
            const depthFactor = Math.max(0.25, (p1A.z + helixRadius) / (helixRadius * 2));
            const alpha = (0.35 + depthFactor * 0.65) * alphaMultiplier;

            // Backbone strand 1 segment
            ctx.beginPath();
            ctx.moveTo(p1A.x, p1A.y);
            ctx.lineTo(p1B.x, p1B.y);
            ctx.strokeStyle = strand1Color;
            ctx.globalAlpha = alpha;
            ctx.lineWidth = Math.max(2.2, 4.2 * p1A.scale);
            ctx.lineCap = 'round';
            ctx.stroke();
            ctx.globalAlpha = 1;

            // Backbone atom sphere node
            ctx.beginPath();
            ctx.arc(p1A.x, p1A.y, Math.max(3.0, 5.2 * p1A.scale), 0, Math.PI * 2);
            ctx.fillStyle = strand1Color;
            ctx.globalAlpha = alpha;
            ctx.shadowColor = strand1Color;
            ctx.shadowBlur = intensity === 'vivid' ? 10 : 5;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.globalAlpha = 1;
          }
        });

        const p2A = projectedStrand2[i];
        const p2B = projectedStrand2[i + 1];

        renderQueue.push({
          type: 'backbone_segment',
          z: (p2A.z + p2B.z) / 2,
          draw: () => {
            const depthFactor = Math.max(0.25, (p2A.z + helixRadius) / (helixRadius * 2));
            const alpha = (0.35 + depthFactor * 0.65) * alphaMultiplier;

            // Backbone strand 2 segment
            ctx.beginPath();
            ctx.moveTo(p2A.x, p2A.y);
            ctx.lineTo(p2B.x, p2B.y);
            ctx.strokeStyle = strand2Color;
            ctx.globalAlpha = alpha;
            ctx.lineWidth = Math.max(2.2, 4.2 * p2A.scale);
            ctx.lineCap = 'round';
            ctx.stroke();
            ctx.globalAlpha = 1;

            // Backbone atom sphere node
            ctx.beginPath();
            ctx.arc(p2A.x, p2A.y, Math.max(3.0, 5.2 * p2A.scale), 0, Math.PI * 2);
            ctx.fillStyle = strand2Color;
            ctx.globalAlpha = alpha;
            ctx.shadowColor = strand2Color;
            ctx.shadowBlur = intensity === 'vivid' ? 10 : 5;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.globalAlpha = 1;
          }
        });
      }

      // 4. Sort by Z-Depth (Back to Front)
      renderQueue.sort((a, b) => b.z - a.z);

      // 5. Draw all items in correct depth order
      for (let i = 0; i < renderQueue.length; i++) {
        renderQueue[i].draw();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [palette, intensity, isPaused]);

  return (
    <div className={`pointer-events-none fixed inset-0 z-0 overflow-hidden ${className}`}>
      {/* 1. Base Rich Dark Foundation */}
      <div className="absolute inset-0 bg-[#080f1a]" />

      {/* 2. Deep Radial Ambient Glow */}
      <div 
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_60%_40%,rgba(18,36,68,0.7)_0%,rgba(8,15,26,0.9)_70%,rgba(5,10,18,0.98)_100%)] pointer-events-none" 
      />

      {/* 3. 3D DNA Helix HTML5 Canvas (Rendered Crisp and Clear) */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{
          opacity: intensity === 'vivid' ? 0.72 : intensity === 'balanced' ? 0.52 : 0.35,
          mixBlendMode: 'screen'
        }}
      />

      {/* 4. Gentle Peripheral Edge Fade Only (Center stays transparent so DNA is seen) */}
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-[#080f1a] to-transparent pointer-events-none opacity-80" />
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#080f1a] to-transparent pointer-events-none opacity-80" />

      {/* 5. Live DNA Helix Active Controller (Bottom-left corner) */}
      <aside 
        aria-label="Live DNA Molecule Controls" 
        className="pointer-events-auto fixed bottom-5 left-5 z-40 hidden md:block"
      >
        {showControls ? (
          <div className="p-3.5 bg-[#080f1a]/95 backdrop-blur-md border border-[#C9A84C]/50 rounded-xl shadow-2xl flex flex-col gap-2.5 text-xs text-[#F5F0E8] w-68 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-[#C9A84C]/20 font-mono-tabular">
              <span className="flex items-center gap-1.5 text-[#C9A84C] font-bold">
                <Dna className="w-3.5 h-3.5 text-[#c6ff00]" />
                Live DNA Helix Active
              </span>
              <button
                type="button"
                onClick={() => setShowControls(false)}
                className="text-white/60 hover:text-white text-[11px] font-mono-tabular cursor-pointer px-1.5 py-0.5 rounded hover:bg-white/10"
              >
                Hide ×
              </button>
            </div>

            {/* Visibility Mode */}
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-[#F5F0E8]/70 flex items-center gap-1">
                <Eye className="w-3 h-3 text-[#C9A84C]" />
                Helix Visibility:
              </span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setIntensity('subtle')}
                  className={`px-2 py-0.5 rounded text-[10px] transition-all cursor-pointer ${
                    intensity === 'subtle'
                      ? 'bg-[#C9A84C] text-[#080f1a] font-bold shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Subtle
                </button>
                <button
                  type="button"
                  onClick={() => setIntensity('balanced')}
                  className={`px-2 py-0.5 rounded text-[10px] transition-all cursor-pointer ${
                    intensity === 'balanced'
                      ? 'bg-[#C9A84C] text-[#080f1a] font-bold shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Balanced
                </button>
                <button
                  type="button"
                  onClick={() => setIntensity('vivid')}
                  className={`px-2 py-0.5 rounded text-[10px] transition-all cursor-pointer ${
                    intensity === 'vivid'
                      ? 'bg-[#c6ff00] text-[#080f1a] font-bold shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Vivid
                </button>
              </div>
            </div>

            {/* Strand Color */}
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-[#F5F0E8]/70">Strand Color:</span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setPalette('lime')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                    palette === 'lime'
                      ? 'bg-[#c6ff00] text-[#080f1a] shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Bio-Lime
                </button>
                <button
                  type="button"
                  onClick={() => setPalette('gold')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                    palette === 'gold'
                      ? 'bg-[#C9A84C] text-[#080f1a] shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Gold
                </button>
                <button
                  type="button"
                  onClick={() => setPalette('cyan')}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                    palette === 'cyan'
                      ? 'bg-[#00e5ff] text-[#080f1a] shadow-xs'
                      : 'bg-white/5 text-[#F5F0E8]/60 hover:text-white'
                  }`}
                >
                  Cyan
                </button>
              </div>
            </div>

            {/* Spin / Pause Toggle */}
            <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5">
              <span className="text-[#F5F0E8]/70">3D Rotation:</span>
              <button
                type="button"
                onClick={() => setIsPaused(!isPaused)}
                className="text-[10px] font-mono-tabular px-2.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-[#C9A84C] cursor-pointer"
              >
                {isPaused ? '▶ Resume Spin' : '⏸ Pause Spin'}
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowControls(true)}
            className="flex items-center gap-2 bg-[#080f1a]/85 hover:bg-[#080f1a] backdrop-blur-md border border-[#C9A84C]/45 rounded-full px-3.5 py-2 text-xs text-[#C9A84C] hover:text-[#e8c96a] shadow-2xl transition-all font-mono-tabular group cursor-pointer"
            title="Adjust live DNA helix wallpaper intensity & colors"
          >
            <Dna className="w-3.5 h-3.5 text-[#c6ff00] animate-spin" style={{ animationDuration: '6s' }} />
            <span className="text-[11px] font-bold">DNA Helix Active</span>
            <Sliders className="w-3 h-3 text-[#C9A84C]/70 group-hover:text-[#C9A84C]" />
          </button>
        )}
      </aside>
    </div>
  );
}
