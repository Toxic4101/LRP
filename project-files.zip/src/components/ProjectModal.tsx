import React from 'react';
import { X, Check, ArrowUpRight, ExternalLink } from 'lucide-react';
import { Project } from '../data/projects';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
  onInquireSimilar: (projectName: string) => void;
}

export function ProjectModal({ project, onClose, onInquireSimilar }: ProjectModalProps) {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-stone-900 border border-stone-800 rounded-xl shadow-2xl p-6 sm:p-8 text-stone-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-stone-400 hover:text-stone-100 bg-stone-800/80 hover:bg-stone-800 rounded-lg transition-colors"
          aria-label="Close project modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Metadata */}
        <div className="flex items-center gap-2 text-xs text-stone-400 font-mono-tabular mb-2">
          <span>{project.client}</span>
          <span aria-hidden="true">·</span>
          <span>{project.category}</span>
          <span aria-hidden="true">·</span>
          <span>Delivered {project.year}</span>
        </div>

        <h3 id="modal-title" className="text-2xl sm:text-3xl font-display font-bold tracking-tight text-stone-100">
          {project.title}
        </h3>

        {/* Project Image */}
        <div className="mt-6 rounded-lg overflow-hidden border border-stone-800 bg-stone-950 aspect-16/9 relative">
          <img
            src={project.image}
            alt={project.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        </div>

        {/* Narrative Description */}
        <p className="mt-6 text-sm sm:text-base text-stone-300 font-body leading-relaxed">
          {project.description}
        </p>

        {/* Verified Performance Metrics */}
        <div className="mt-8 pt-6 border-t border-stone-800">
          <h4 className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-4">
            Quantified Performance Outcomes
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {project.metrics.map((metric, i) => (
              <div key={i} className="p-4 bg-stone-950/70 border border-stone-800 rounded-lg">
                <div className="text-xl sm:text-2xl font-display font-bold text-amber-400 font-mono-tabular">
                  {metric.primary}
                </div>
                <div className="text-xs text-stone-400 mt-1">{metric.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Deliverables & Technology Stack */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-stone-800">
          <div>
            <h4 className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-3">
              Delivered Architectural Assets
            </h4>
            <ul className="space-y-2 text-xs text-stone-300">
              {project.deliverables.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-3">
              Production Technology Stack
            </h4>
            <div className="flex flex-wrap gap-2">
              {project.stack.map((tech, i) => (
                <span 
                  key={i} 
                  className="px-2.5 py-1 text-xs font-mono-tabular bg-stone-950 text-stone-300 border border-stone-800 rounded"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Client Quote */}
        <div className="mt-8 p-5 bg-stone-950/50 border-l-2 border-amber-400 rounded-r-lg">
          <p className="text-xs sm:text-sm text-stone-300 italic font-body">
            &ldquo;{project.clientQuote.quote}&rdquo;
          </p>
          <div className="mt-2 text-xs text-stone-400">
            <span className="font-semibold text-stone-200">{project.clientQuote.author}</span>
            <span aria-hidden="true"> · </span>
            <span>{project.clientQuote.role}, {project.clientQuote.organization}</span>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-8 pt-6 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={() => {
              onClose();
              onInquireSimilar(project.title);
            }}
            className="px-5 py-2.5 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-2"
          >
            <span>Inquire About Similar Architecture</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2.5 text-xs text-stone-400 hover:text-stone-200 transition-colors"
          >
            Dismiss
          </button>
        </div>

      </div>
    </div>
  );
}
