import React, { useState } from 'react';

interface ChacoGoldenSpiderProps {
  className?: string;
  size?: number; // width/height in px
  showTooltip?: boolean;
}

/**
 * Chaco Golden Knee Spider Symbol (Grammostola pulchripes)
 * Designed with aggressive stance, sharp predatory chelicerae fangs,
 * glowing ocular eye cluster, and signature vibrant golden knee joints.
 */
export function ChacoGoldenSpider({
  className = '',
  size = 34,
  showTooltip = true,
}: ChacoGoldenSpiderProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={`relative inline-flex items-center justify-center group cursor-pointer ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title="Chaco Golden Knee (Grammostola pulchripes)"
    >
      {/* Dangerous ambient threat glow behind spider */}
      <div 
        className={`absolute inset-0 rounded-full bg-gradient-to-r from-[#C9A84C]/30 via-[#E5B83B]/20 to-transparent blur-md transition-all duration-300 pointer-events-none ${
          isHovered ? 'scale-150 opacity-100' : 'scale-90 opacity-40'
        }`}
      />

      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`relative z-10 transition-transform duration-300 drop-shadow-[0_2px_8px_rgba(201,168,76,0.5)] ${
          isHovered ? 'scale-110 -rotate-3' : 'scale-100 rotate-0'
        }`}
      >
        <defs>
          {/* Chitin body gradient */}
          <linearGradient id="chitinGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#222b3b" />
            <stop offset="50%" stopColor="#0e1724" />
            <stop offset="100%" stopColor="#050a12" />
          </linearGradient>

          {/* Dangerous Golden Knee Joint Gradient */}
          <linearGradient id="chacoGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF2A3" />
            <stop offset="40%" stopColor="#F5C542" />
            <stop offset="100%" stopColor="#C9942A" />
          </linearGradient>

          {/* Venom & Eye Glint Glow */}
          <radialGradient id="eyeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FF4A4A" />
            <stop offset="60%" stopColor="#E5B83B" />
            <stop offset="100%" stopColor="#7A1800" />
          </radialGradient>

          <filter id="spiderGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#C9A84C" floodOpacity="0.7" />
          </filter>
        </defs>

        {/* ── 8 LEGS WITH DANGEROUS CHACO GOLDEN KNEE STRIPES ── */}
        {/* Rear Legs Pair 4 (Arching back aggressively) */}
        <g stroke="#1b2535" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          {/* Leg 4 Left */}
          <path d="M 44 65 L 26 78 L 12 92 L 6 95" />
          {/* Leg 4 Right */}
          <path d="M 56 65 L 74 78 L 88 92 L 94 95" />
        </g>
        {/* Golden Knee stripes for Leg 4 */}
        <g stroke="url(#chacoGold)" strokeWidth="3.2" strokeLinecap="round">
          <line x1="24" y1="76" x2="28" y2="80" />
          <line x1="20" y1="82" x2="23" y2="85" />
          <line x1="72" y1="80" x2="76" y2="76" />
          <line x1="77" y1="85" x2="80" y2="82" />
        </g>

        {/* Mid-Rear Legs Pair 3 */}
        <g stroke="#1e293b" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
          {/* Leg 3 Left */}
          <path d="M 42 54 L 20 62 L 6 72 L 2 76" />
          {/* Leg 3 Right */}
          <path d="M 58 54 L 80 62 L 94 72 L 98 76" />
        </g>
        {/* Golden Knee stripes for Leg 3 */}
        <g stroke="url(#chacoGold)" strokeWidth="3.4" strokeLinecap="round">
          <line x1="18" y1="60" x2="22" y2="64" />
          <line x1="12" y1="66" x2="15" y2="70" />
          <line x1="78" y1="64" x2="82" y2="60" />
          <line x1="85" y1="70" x2="88" y2="66" />
        </g>

        {/* Mid-Forward Legs Pair 2 (Spreading wide) */}
        <g stroke="#243247" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
          {/* Leg 2 Left */}
          <path d="M 43 45 L 22 38 L 8 42 L 3 45" />
          {/* Leg 2 Right */}
          <path d="M 57 45 L 78 38 L 92 42 L 97 45" />
        </g>
        {/* Golden Knee stripes for Leg 2 */}
        <g stroke="url(#chacoGold)" strokeWidth="3.4" strokeLinecap="round">
          <line x1="20" y1="36" x2="24" y2="40" />
          <line x1="14" y1="39" x2="16" y2="43" />
          <line x1="76" y1="40" x2="80" y2="36" />
          <line x1="84" y1="43" x2="86" y2="39" />
        </g>

        {/* Front Striking Legs Pair 1 (Raised high in dangerous threat posture) */}
        <g stroke="#283850" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
          {/* Leg 1 Left */}
          <path d="M 45 38 L 28 20 L 18 10 L 14 6" />
          {/* Leg 1 Right */}
          <path d="M 55 38 L 72 20 L 82 10 L 86 6" />
        </g>
        {/* Golden Knee stripes for Leg 1 */}
        <g stroke="url(#chacoGold)" strokeWidth="3.6" strokeLinecap="round">
          <line x1="26" y1="18" x2="30" y2="22" />
          <line x1="22" y1="13" x2="25" y2="16" />
          <line x1="70" y1="22" x2="74" y2="18" />
          <line x1="75" y1="16" x2="78" y2="13" />
        </g>

        {/* Sharp Claws at tips of all legs */}
        <g stroke="#C9A84C" strokeWidth="1.2" strokeLinecap="round">
          <line x1="14" y1="6" x2="12" y2="4" />
          <line x1="86" y1="6" x2="88" y2="4" />
          <line x1="3" y1="45" x2="1" y2="46" />
          <line x1="97" y1="45" x2="99" y2="46" />
          <line x1="2" y1="76" x2="1" y2="78" />
          <line x1="98" y1="76" x2="99" y2="78" />
          <line x1="6" y1="95" x2="5" y2="98" />
          <line x1="94" y1="95" x2="95" y2="98" />
        </g>

        {/* Forward Pedipalps (Sensory arms in front of fangs) */}
        <g stroke="#202c3e" strokeWidth="2.5" strokeLinecap="round">
          <path d="M 46 32 L 38 22 L 36 15" />
          <path d="M 54 32 L 62 22 L 64 15" />
        </g>
        <g stroke="url(#chacoGold)" strokeWidth="2.8" strokeLinecap="round">
          <line x1="37" y1="20" x2="39" y2="23" />
          <line x1="61" y1="23" x2="63" y2="20" />
        </g>

        {/* ── ABDOMEN (Opisthosoma) with heavy setae texture ── */}
        <ellipse cx="50" cy="68" rx="14" ry="19" fill="url(#chitinGrad)" stroke="#C9A84C" strokeWidth="1.2" />
        {/* Abdomen Bristle & Stripe Pattern */}
        <g stroke="#C9A84C" strokeWidth="0.8" opacity="0.6" strokeLinecap="round">
          <path d="M 44 58 Q 50 60 56 58" />
          <path d="M 42 64 Q 50 67 58 64" />
          <path d="M 43 70 Q 50 73 57 70" />
          <path d="M 45 76 Q 50 78 55 76" />
          <line x1="50" y1="56" x2="50" y2="82" strokeDasharray="1 2" strokeWidth="1" />
        </g>

        {/* ── CARAPACE (Cephalothorax) ── */}
        <ellipse cx="50" cy="44" rx="11" ry="12" fill="url(#chitinGrad)" stroke="#C9A84C" strokeWidth="1.5" />
        {/* Carapace Radiating Fovea lines */}
        <g stroke="#E5B83B" strokeWidth="0.8" opacity="0.75" strokeLinecap="round">
          <line x1="50" y1="45" x2="44" y2="40" />
          <line x1="50" y1="45" x2="56" y2="40" />
          <line x1="50" y1="45" x2="43" y2="46" />
          <line x1="50" y1="45" x2="57" y2="46" />
          <line x1="50" y1="45" x2="50" y2="52" />
        </g>

        {/* ── DANGEROUS CHELICERAE & CURVED VENOM FANGS ── */}
        <g id="fangs">
          {/* Left Chelicera */}
          <path d="M 44 32 L 44 24 L 48 24 L 48 32 Z" fill="#141c28" stroke="#C9A84C" strokeWidth="1" />
          {/* Right Chelicera */}
          <path d="M 52 32 L 52 24 L 56 24 L 56 32 Z" fill="#141c28" stroke="#C9A84C" strokeWidth="1" />
          
          {/* Razor Sharp Downward Venom Fangs */}
          <path 
            d="M 45 24 Q 43 18 40 16" 
            stroke="#FFF2A3" 
            strokeWidth="1.8" 
            strokeLinecap="round" 
            filter="url(#spiderGlow)" 
          />
          <path 
            d="M 55 24 Q 57 18 60 16" 
            stroke="#FFF2A3" 
            strokeWidth="1.8" 
            strokeLinecap="round" 
            filter="url(#spiderGlow)" 
          />
          
          {/* Glistening Venom Drops at Fang Tips */}
          <circle cx="40" cy="16" r="1.2" fill="#FFE866" className="animate-pulse" />
          <circle cx="60" cy="16" r="1.2" fill="#FFE866" className="animate-pulse" />
        </g>

        {/* ── PREDATORY OCULAR CLUSTER (Glowing Amber Eyes) ── */}
        <g id="eyes">
          {/* Principal Anterior Median Eyes */}
          <circle cx="48.5" cy="35" r="1.4" fill="url(#eyeGlow)" />
          <circle cx="51.5" cy="35" r="1.4" fill="url(#eyeGlow)" />
          {/* Anterior Lateral Eyes */}
          <circle cx="46.5" cy="36.5" r="1.1" fill="url(#eyeGlow)" />
          <circle cx="53.5" cy="36.5" r="1.1" fill="url(#eyeGlow)" />
          {/* Posterior Median & Lateral Eyes */}
          <circle cx="48" cy="37.8" r="0.9" fill="#E5B83B" />
          <circle cx="52" cy="37.8" r="0.9" fill="#E5B83B" />
          <circle cx="45.5" cy="38" r="0.8" fill="#E5B83B" />
          <circle cx="54.5" cy="38" r="0.8" fill="#E5B83B" />
        </g>
      </svg>

      {/* Dangerous Hover Tooltip */}
      {showTooltip && (
        <div className="absolute top-full left-0 mt-2 z-50 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <div className="bg-[#050b14]/95 border border-[#C9A84C]/60 backdrop-blur-md px-2.5 py-1.5 rounded-lg shadow-xl shadow-black/90 whitespace-nowrap text-left">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E5B83B] animate-ping" />
              <p className="text-[10px] font-extrabold uppercase tracking-widest text-[#E5B83B]">
                Chaco Golden Knee
              </p>
            </div>
            <p className="text-[9px] text-[#F5F0E8]/70 font-mono-tabular italic">
              Grammostola pulchripes
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
