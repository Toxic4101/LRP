import React from 'react';
import { Palette } from 'lucide-react';

interface NavbarProps {
  currentTheme: string;
  onThemeCycle: () => void;
  onRequestConsultation: () => void;
}

export function Navbar({ currentTheme, onThemeCycle, onRequestConsultation }: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 bg-stone-950/85 backdrop-blur-md border-b border-stone-800">
      <div className="max-w-7xl mx-auto px-6 md:px-12 h-18 flex items-center justify-between">
        
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#" 
          className="text-lg font-display font-bold tracking-tight text-stone-100 hover:text-amber-400 transition-colors shrink-0"
        >
          Vanguard Studio
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-400">
          <a href="#works" className="hover:text-stone-100 transition-colors">
            Selected Works
          </a>
          <a href="#capabilities" className="hover:text-stone-100 transition-colors">
            Capabilities
          </a>
          <a href="#prototypes" className="hover:text-stone-100 transition-colors">
            Interactive Showcase
          </a>
          <a href="#estimator" className="hover:text-stone-100 transition-colors">
            Estimator
          </a>
          <a href="#philosophy" className="hover:text-stone-100 transition-colors">
            Philosophy
          </a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onThemeCycle}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-mono-tabular text-stone-400 hover:text-stone-200 border border-stone-800 rounded-lg hover:border-stone-700 transition-colors whitespace-nowrap"
            title="Cycle visual accent theme"
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="capitalize hidden sm:inline">{currentTheme}</span>
          </button>

          <button
            onClick={onRequestConsultation}
            className="px-4 py-2 text-xs font-semibold text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            Request Consultation
          </button>
        </div>

      </div>
    </header>
  );
}
