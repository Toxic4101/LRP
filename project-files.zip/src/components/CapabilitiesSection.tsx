import React from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { CAPABILITIES } from '../data/capabilities';

interface CapabilitiesSectionProps {
  onRequestQuote: (serviceTitle: string) => void;
}

export function CapabilitiesSection({ onRequestQuote }: CapabilitiesSectionProps) {
  return (
    <section id="capabilities" className="py-24 px-6 md:px-12 max-w-7xl mx-auto border-t border-stone-800">
      {/* Editorial Header */}
      <div className="max-w-3xl mb-16">
        <div className="flex items-center gap-2 text-xs text-stone-400 mb-2 font-mono-tabular">
          <span>Core Capabilities</span>
          <span aria-hidden="true">·</span>
          <span>End-to-End Delivery</span>
          <span aria-hidden="true">·</span>
          <span>Production Engineering</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-stone-100" style={{ textWrap: 'balance' }}>
          What We Architect & Build For You
        </h2>
        <p className="mt-3 text-stone-400 text-sm md:text-base font-body leading-relaxed">
          We do not use generic page builders or bloated pre-made templates. Every line of code is structured for peak performance, pristine responsive rendering, and measurable commercial conversion.
        </p>
      </div>

      {/* Numbered Editorial Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {CAPABILITIES.map((cap) => (
          <div 
            key={cap.number}
            className="p-8 bg-stone-900/40 border border-stone-800 rounded-xl flex flex-col justify-between hover:border-stone-700 transition-colors"
          >
            <div>
              <div className="flex items-baseline justify-between mb-4">
                <span className="font-display font-bold text-2xl text-amber-400 font-mono-tabular">
                  {cap.number}.
                </span>
                <span className="text-xs text-stone-400 font-mono-tabular">
                  {cap.metrics}
                </span>
              </div>

              <h3 className="text-xl font-display font-semibold text-stone-100 mb-3">
                {cap.title}
              </h3>

              <p className="text-sm text-stone-400 font-body leading-relaxed mb-6">
                {cap.summary}
              </p>

              <div className="space-y-2 border-t border-stone-800/80 pt-5">
                <div className="text-xs font-mono-tabular text-stone-400 uppercase tracking-wider mb-2">
                  Key Deliverables
                </div>
                {cap.deliverables.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-stone-300">
                    <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-stone-800/60">
              <button
                onClick={() => onRequestQuote(cap.title)}
                className="text-xs font-medium text-stone-300 hover:text-amber-400 transition-colors flex items-center gap-1.5"
              >
                <span>Request Scope for {cap.title}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
