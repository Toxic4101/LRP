/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { LiveBackWall } from './components/LiveBackWall';
import { TopNav } from './components/TopNav';
import { HeroSection } from './components/HeroSection';
import { HowItWorks } from './components/HowItWorks';
import { WhatWeAccept } from './components/WhatWeAccept';
import { WhoItsFor } from './components/WhoItsFor';
import { LeadershipSection } from './components/LeadershipSection';
import { CtaBanner } from './components/CtaBanner';
import { SignUpForm } from './components/SignUpForm';
import { SiteFooter } from './components/SiteFooter';

export default function App() {
  return (
    <div className="min-h-screen bg-[#080f1a] text-[#F5F0E8] font-sans antialiased selection:bg-[#C9A84C] selection:text-[#080f1a] relative">
      {/* Live Animated 3D DNA Double Helix Background Wall */}
      <LiveBackWall />

      {/* Fixed Navigation & Logo Bar */}
      <TopNav />

      {/* Main Page Content (Translucent & Frosted Glass Backing for 100% Readability) */}
      <main className="relative z-10">
        {/* Hero Section with Interactive Drum Simulation */}
        <HeroSection />

        {/* How It Works (1-2-3 Operational Workflow) */}
        <HowItWorks />

        {/* What We Accept (Searchable Recyclables Matrix) */}
        <WhatWeAccept />

        {/* Who It's For (Households & Commercial Businesses) */}
        <WhoItsFor />

        {/* Leadership Section */}
        <LeadershipSection />

        {/* CTA Banner */}
        <CtaBanner />

        {/* Direct Sign-Up & Contact Desk with WhatsApp & Direct Call Routing */}
        <SignUpForm />
      </main>

      {/* Site Footer */}
      <SiteFooter />
    </div>
  );
}
