export interface Project {
  id: string;
  title: string;
  client: string;
  category: string;
  year: string;
  image: string;
  description: string;
  metrics: {
    primary: string;
    label: string;
  }[];
  stack: string[];
  deliverables: string[];
  clientQuote: {
    quote: string;
    author: string;
    role: string;
    organization: string;
  };
}

export const PROJECTS: Project[] = [
  {
    id: 'chronos',
    title: 'Chronos Horology Atelier',
    client: 'Chronos Timepieces',
    category: 'Luxury E-Commerce & Merchant Infrastructure',
    year: '2026',
    image: '/src/assets/images/project_luxury_timepiece_1791403271227.jpg',
    description: 'An ultra-refined digital flagship for an independent Swiss watchmaker. Engineered with interactive 360-degree case inspection, bespoke dial configuration, and a friction-free multi-currency checkout engine.',
    metrics: [
      { primary: '+184%', label: 'Checkout Conversion Rate' },
      { primary: '390ms', label: 'Median First Contentful Paint' },
      { primary: '$3.4M', label: 'Online Sales in Q1 2026' }
    ],
    stack: ['React', 'TypeScript', 'Tailwind CSS', 'Shopify Storefront API', 'Stripe Elements'],
    deliverables: [
      'Custom Bespoke Design System',
      'High-Resolution Product Visualizer',
      'Inventory Sync Engine',
      'Global Currency & Tax Automation'
    ],
    clientQuote: {
      quote: 'Vanguard delivered an e-commerce flagship that rivals our physical Geneva boutique in tactile prestige and precision.',
      author: 'Marc-André Vaneck',
      role: 'Managing Director',
      organization: 'Chronos Horology SA'
    }
  },
  {
    id: 'kallio',
    title: 'Kallio Architectural Monograph',
    client: 'Kallio & Partners Architects',
    category: 'Editorial Architecture & Portfolio Archive',
    year: '2026',
    image: '/src/assets/images/project_nordic_architecture_1791403280324.jpg',
    description: 'A museum-grade digital monograph documenting sustainable timber architecture and Nordic residential pavilions across Finland and Norway. Designed with strict typographic rhythm and bespoke blueprint viewer.',
    metrics: [
      { primary: '1.2M', label: 'Global Editorial Impressions' },
      { primary: '4m 12s', label: 'Average Session Dwell Time' },
      { primary: '100/100', label: 'Lighthouse Accessibility Score' }
    ],
    stack: ['React 19', 'Vite', 'Tailwind CSS', 'WebGL Viewport', 'Headless CMS'],
    deliverables: [
      'Spatial Architectural Layouts',
      'Interactive Elevation Blueprint Viewer',
      'Monograph Article Publishing System',
      'Full Responsive Viewport Optimization'
    ],
    clientQuote: {
      quote: 'The website captures the quiet austerity and natural illumination of our buildings with remarkable digital fidelity.',
      author: 'Elin Lindqvist',
      role: 'Founding Partner',
      organization: 'Kallio Architects'
    }
  },
  {
    id: 'nordhavn',
    title: 'Nordhavn Specialty Roastery',
    client: 'Nordhavn Coffee Supply',
    category: 'Direct-to-Consumer & Subscription Platform',
    year: '2026',
    image: '/src/assets/images/project_artisanal_roastery_1791403290216.jpg',
    description: 'A direct-to-consumer subscription engine and sensory tasting guide for single-origin coffees. Combines roast profiling interactive sliders with automated bi-weekly recurring deliveries.',
    metrics: [
      { primary: '+310%', label: 'Active Monthly Subscribers' },
      { primary: '$820k', label: 'Recurring Subscription ARR' },
      { primary: '0.42s', label: 'Mobile Cart Interaction Latency' }
    ],
    stack: ['TypeScript', 'React', 'Tailwind CSS', 'Recharge API', 'Express Backend'],
    deliverables: [
      'Sensory Flavor Radar Customizer',
      'Recurring Subscription Frequency Selector',
      'Automated Order Tracking Portal',
      'Wholesale B2B Partner Application Portal'
    ],
    clientQuote: {
      quote: 'Our subscriber retention spiked immediately after launch. The tactile elegance of the ordering flow is unmatched.',
      author: 'Søren Møller',
      role: 'Head of Operations',
      organization: 'Nordhavn Coffee Supply'
    }
  }
];
