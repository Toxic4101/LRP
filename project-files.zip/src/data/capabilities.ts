export interface Capability {
  number: string;
  title: string;
  summary: string;
  deliverables: string[];
  metrics: string;
}

export const CAPABILITIES: Capability[] = [
  {
    number: '01',
    title: 'Bespoke Art Direction & Brand Systems',
    summary: 'We craft intentional typographic hierarchies, tailored palettes, and responsive design systems that establish immediate authority and brand distinction.',
    deliverables: [
      'Tailored Design Tokens & Theme Palettes',
      'Editorial & Monograph Typography Pairings',
      'Component Architecture & Design Specs',
      'Interactive Micro-Interactions & Motion'
    ],
    metrics: '100% Custom Tailored (Zero Templates)'
  },
  {
    number: '02',
    title: 'High-Performance Frontend Engineering',
    summary: 'Production-ready code engineered with React, TypeScript, and modern bundlers. Built for sub-second page loads, fluid responsiveness, and strict accessibility.',
    deliverables: [
      'Sub-500ms Core Web Vitals Optimization',
      'Semantic HTML5 & WCAG AA Accessible Markup',
      'Fluid Multi-Device Layouts (Mobile to 4K)',
      'Smooth CSS & Hardware-Accelerated Animations'
    ],
    metrics: '<0.45s Median First Paint'
  },
  {
    number: '03',
    title: 'E-Commerce & Merchant Infrastructure',
    summary: 'Custom storefronts, high-converting product detail pages, and automated subscription engines that turn visitors into loyal customers.',
    deliverables: [
      'Bespoke Product Customizers & Variant Pickers',
      'Streamlined Checkout & Frictionless Cart Drawers',
      'Stripe & Headless Merchant Integrations',
      'Order Status & Customer Account Portals'
    ],
    metrics: '+42% Average Conversion Lift'
  },
  {
    number: '04',
    title: 'Full-Stack Web Applications & Integrations',
    summary: 'Complete web apps with database persistence, user authentication, live interactive calculation tools, and custom internal workflows.',
    deliverables: [
      'REST & GraphQL API Integration',
      'Authentication & Protected Member Portals',
      'Dynamic Data Dashboards & Real-time Feeds',
      'Automated Lead Routing & CRM Pipelines'
    ],
    metrics: '99.9% Uptime Reliability'
  }
];
